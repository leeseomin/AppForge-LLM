# Changelog

## 0.3.0 — 2026-06-26

- Rebuilt the web frontend as a Vite + Vue single-page app under `frontend/`.
- Added Vue components for the composer, health banner, stage timeline, event feed, error panel, and toast notifications.
- Added SPA-friendly FastAPI static serving for Vite assets, manifest, favicon, and browser refresh fallback.
- Preserved the existing backend job manager, pipeline runner, pipeline manifests, gates, retries, and ZIP validation logic.
- Updated packaging to include recursive Vite build assets under `appforge/resources/web/`.

## 0.2.0 — 2026-06-26

- Added the minimal single-flow `appforge web` user experience.
- Added automatic driver readiness, pipeline routing, and one-active-job control.
- Added per-stage pending/running/validating/retrying/completed/failed status reporting.
- Added structured runner events and detailed failure payloads with redacted agent output and failed gates.
- Added persisted web-job state and refresh recovery.
- Added verified ZIP download activation only after full pipeline completion.
- Added responsive, accessible, dependency-free browser UI with no external assets.
- Added FastAPI integration and end-to-end web tests.

## 0.1.0 — 2026-06-25

- Initial OpenAppForge release.
- Twelve software production pipelines.
- Repository-native stage skills and assistant adapters.
- Codex, Claude Code, and generic command drivers.
- Schema-validated artifacts, deterministic gates, retries, approvals, and checkpoints.
- Safety-controlled tools for quality, security, compliance, and release packaging.
- One-command `appforge forge` workflow and manual agent-native loop.
