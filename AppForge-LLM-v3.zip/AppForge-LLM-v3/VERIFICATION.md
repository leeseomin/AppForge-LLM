# Verification record

Date: 2026-06-26  
Version: 0.3.0

## Automated checks performed in this package

- `npm --prefix frontend install` — completed; npm audit reported 0 vulnerabilities.
- `npm --prefix frontend run build` — Vue typecheck and Vite production build completed.
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=. python -m compileall -q appforge tests` — passed.
- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=. python -m pytest -q` — **21 passed**.
- `python -m pip wheel . --no-deps --no-build-isolation -w dist` — built `openappforge-0.3.0-py3-none-any.whl`.
- Wheel smoke check — installed the wheel into an isolated target, loaded version `0.3.0`, served `/`, served the hashed Vite JavaScript asset, and returned ready `/api/health` with the generic fixture driver.

## Web-job coverage retained

- Deterministic generic-driver integration runs the complete prototype pipeline through archive validation and HTTP ZIP download.
- Failure-path tests preserve missing-agent setup errors and agent exit code `7` as structured web errors.
- Static serving tests verify the v3 HTML shell, module asset serving, manifest, SPA refresh fallback, and API 404 behavior.

## Shipped production surface

- Pipelines: 12
- Auto-discovered tools: 25
- Markdown skills: 56
- Artifact schemas: 22
- Built browser assets: Vite HTML shell, manifest, favicon, CSS bundle, JavaScript bundle
- Web API: health, job creation, job status, verified ZIP download
- Built wheel: `openappforge-0.3.0-py3-none-any.whl`
- Wheel SHA-256: `c8ecf0b219d9d07dfeb4358fcb5c86635f9371183ab3f8e2440318526375585e`

## Environment limitation

Codex CLI and Claude Code CLI were not installed in the build environment, so live vendor-model executions were not performed. Their adapters remain covered by unit/construction checks. The generic driver was exercised end to end through the web workflow, including stage events, tests, packaging, download, and detailed error propagation.
