from __future__ import annotations

import zipfile

import pytest

from appforge.tooling.command import CommandPolicy, run_command
from appforge.tooling.registry import ToolRegistry
from appforge.util import safe_resolve


def test_registry_discovers_unique_tool_contracts() -> None:
    registry = ToolRegistry()
    names = registry.names()
    assert len(names) >= 20
    assert len(names) == len(set(names))
    assert {"run_tests", "secret_scan", "archive_workspace", "release_readiness"}.issubset(names)


def test_workspace_escape_is_rejected(tmp_path) -> None:
    with pytest.raises(ValueError):
        safe_resolve(tmp_path, "../outside.txt")


def test_destructive_tools_require_explicit_opt_in(tmp_path) -> None:
    tool = ToolRegistry().get("write_text")
    denied = tool.run(tmp_path, {"path": "hello.txt", "content": "hello"})
    assert not denied.success
    allowed = tool.run(
        tmp_path,
        {"path": "hello.txt", "content": "hello", "allow_destructive": True},
    )
    assert allowed.success
    assert (tmp_path / "hello.txt").read_text(encoding="utf-8") == "hello"


def test_secret_scan_redacts_preview(tmp_path) -> None:
    secret = "ghp_" + ("a" * 36)
    key_name = "to" + "ken"
    (tmp_path / "config.txt").write_text(f'{key_name} = "{secret}"\n', encoding="utf-8")
    result = ToolRegistry().get("secret_scan").run(tmp_path, {})
    assert not result.success
    rendered = str(result.data)
    assert secret not in rendered
    assert "redacted" in rendered


def test_archive_excludes_secret_material_and_internal_state(tmp_path) -> None:
    (tmp_path / ".appforge" / "reports").mkdir(parents=True)
    (tmp_path / "src").mkdir()
    (tmp_path / "src" / "app.py").write_text("print('ok')\n", encoding="utf-8")
    (tmp_path / ".env").write_text("TOKEN=secret\n", encoding="utf-8")
    (tmp_path / ".env.local").write_text("TOKEN=secret\n", encoding="utf-8")
    (tmp_path / ".env.example").write_text("TOKEN=your-api-key\n", encoding="utf-8")
    (tmp_path / "server.pem").write_text("private\n", encoding="utf-8")
    (tmp_path / ".appforge" / "project.json").write_text("{}\n", encoding="utf-8")

    result = ToolRegistry().get("archive_workspace").run(tmp_path, {})
    assert result.success
    archive_path = tmp_path / result.data["archive"]
    with zipfile.ZipFile(archive_path) as archive:
        names = set(archive.namelist())
    assert "src/app.py" in names
    assert ".env.example" in names
    assert ".env" not in names
    assert ".env.local" not in names
    assert "server.pem" not in names
    assert not any(name.startswith(".appforge/") for name in names)


def test_command_policy_blocks_network_and_destructive_patterns(tmp_path) -> None:
    with pytest.raises(PermissionError):
        run_command(tmp_path, ["curl", "https://example.com"], policy=CommandPolicy())
    with pytest.raises(PermissionError):
        run_command(tmp_path, ["git", "reset", "--hard"], policy=CommandPolicy())
