"""Auto-discovered OpenAppForge tools."""
