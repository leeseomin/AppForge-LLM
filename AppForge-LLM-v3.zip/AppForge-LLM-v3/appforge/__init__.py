"""OpenAppForge: pipeline-driven software production for coding agents."""

from __future__ import annotations

__all__ = ["__version__"]
__version__ = "0.3.0"
