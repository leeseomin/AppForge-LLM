# AppForge-LLM v2 Web Application

The v2 web application is the default user experience for greenfield application generation. It intentionally exposes one goal-oriented path rather than the full orchestration option surface.

## Start

```bash
python -m pip install dist/openappforge-0.2.0-py3-none-any.whl
appforge web
```

For source development, install the checkout with `python -m pip install -e .`.

Equivalent standalone entry point:

```bash
appforge-web
```

Useful server-only flags:

```bash
appforge web --host 127.0.0.1 --port 8787 --no-open-browser
```

The default bind address is loopback-only. Binding to `0.0.0.0` exposes the interface to the surrounding network and should only be done behind appropriate host, authentication, and network controls.

## User journey

1. The page checks coding-agent readiness.
2. The user enters one natural-language application request.
3. `POST /api/jobs` automatically selects the pipeline and starts one background job.
4. The browser polls `GET /api/jobs/{id}` and renders every system and pipeline stage.
5. Failed attempts appear as `retrying` while attempts remain.
6. A terminal failure includes a stable code, action, stage, attempt, agent result, failed checks, and critical review findings.
7. On success, the server validates the ZIP and sets `download.available=true`.
8. `GET /api/jobs/{id}/download` serves only that job's verified archive.

The UI stores only the active job ID in browser local storage. Authoritative job state is persisted in `.appforge-web/jobs/<job-id>.json`.

## Job statuses

```text
queued → initializing → running → packaging → completed
                                      └────────→ failed
```

Stage statuses are:

```text
pending | running | validating | retrying | completed | failed
```

The overall percentage is derived from all visible system and pipeline stages. It reaches 100 only after archive validation succeeds.

## API

### `GET /api/health`

Returns server version, driver readiness, active-job ID, network policy, and safety policy. The UI disables the start action until a supported coding-agent executable is available.

### `POST /api/jobs`

Request:

```json
{
  "prompt": "Build a responsive local-first budget web app with tests."
}
```

Returns HTTP 202 and the complete public job snapshot. Only one job may be active; a second request returns HTTP 409 with `error.context.current_job_id` so the client can reconnect to the existing run.

### `GET /api/jobs/{job_id}`

Returns the current snapshot, including:

- pipeline and project information;
- ordered stage records;
- progress and active stage;
- compact event history;
- structured terminal error;
- download availability, URL, filename, and size.

### `GET /api/jobs/{job_id}/download`

Returns HTTP 409 until the job completes. The path is resolved from server-owned job state and must remain under the project's `.appforge/reports/` directory.

## Configuration

| Variable | Default | Purpose |
|---|---:|---|
| `APPFORGE_PROJECTS_DIR` | `projects` | Generated workspaces |
| `APPFORGE_DATA_DIR` | `.appforge-web` | Persisted web-job state |
| `APPFORGE_DRIVER` | `auto` | `auto`, `codex`, `claude`, or `generic` |
| `APPFORGE_AGENT_CMD` | unset | Generic command template |
| `APPFORGE_MODEL` | unset | Model passed to Codex/Claude driver |
| `APPFORGE_ALLOW_NETWORK` | `true` | Dependency downloads and remote audits |
| `APPFORGE_ALLOW_DESTRUCTIVE` | `false` | Destructive AppForge tools; keep disabled for normal web use |
| `APPFORGE_UNSAFE_AGENT` | `false` | Agent sandbox bypass; isolated environments only |
| `APPFORGE_STAGE_TIMEOUT` | `3600` | Per-stage timeout in seconds |
| `APPFORGE_MAX_STAGE_ATTEMPTS` | pipeline default | Override automatic attempts |
| `APPFORGE_MAX_TURNS` | unset | Claude Code turn limit |
| `APPFORGE_PROMPT_MAX_CHARS` | `20000` | Request input limit |

Boolean values accept `true/false`, `1/0`, `yes/no`, or `on/off`.

## Error contract

API errors use:

```json
{
  "error": {
    "code": "STAGE_CHECK_FAILED",
    "title": "필수 검증을 통과하지 못했습니다",
    "message": "Required validation failed in stage verification: run_tests",
    "action": "Fix the failed check and retry.",
    "stage": "verification",
    "attempt": 2,
    "technical": {
      "driver": {},
      "failed_checks": [],
      "review_findings": []
    }
  }
}
```

Captured agent output is passed through the framework's secret redaction and size limits before it reaches web-job state or the browser.

## Persistence and restart behavior

Job snapshots are written atomically after meaningful state changes. A process restart cannot resume a subprocess that was already executing, so any persisted `queued`, `initializing`, `running`, or `packaging` job is converted to a terminal `SERVER_RESTARTED` failure during startup. The generated project and `.appforge/` checkpoints remain available for CLI inspection or a new web run.

Completed jobs remain downloadable while their archive exists. If the archive is moved or deleted, the persisted record becomes an `ARCHIVE_MISSING` failure on the next server startup.

## Security boundaries

- Default binding is `127.0.0.1`.
- No CORS policy is enabled.
- API and page responses use `Cache-Control: no-store`.
- Responses include restrictive CSP, frame, referrer, MIME, and permissions headers.
- The client renders all dynamic text with DOM `textContent`, not HTML injection.
- Download paths are never accepted from clients.
- The archive tool excludes secrets, VCS state, dependencies, caches, and `.appforge/` runtime files.
- The web workflow never enables deployment.
- One active job avoids ambiguous state and local resource contention.

The application does not provide multi-user authentication. Keep it loopback-only unless an external authenticated reverse proxy and operating-system isolation are in place.
