(() => {
  "use strict";

  const STORAGE_KEY = "appforge-v2-current-job";
  const ACTIVE_STATUSES = new Set(["queued", "initializing", "running", "packaging"]);
  const STATUS_LABELS = {
    pending: "대기",
    running: "실행 중",
    validating: "검증 중",
    retrying: "자동 재시도",
    completed: "완료",
    failed: "실패",
  };

  const state = {
    currentJobId: window.localStorage.getItem(STORAGE_KEY),
    pollTimer: null,
    health: null,
    job: null,
    submitting: false,
    toastTimer: null,
  };

  const elements = {
    form: document.querySelector("#forgeForm"),
    prompt: document.querySelector("#promptInput"),
    characterCount: document.querySelector("#characterCount"),
    startButton: document.querySelector("#startButton"),
    startButtonLabel: document.querySelector("#startButtonLabel"),
    readinessNotice: document.querySelector("#readinessNotice"),
    serverBadge: document.querySelector("#serverBadge"),
    serverBadgeText: document.querySelector("#serverBadgeText"),
    jobPanel: document.querySelector("#jobPanel"),
    jobStatusPill: document.querySelector("#jobStatusPill"),
    pipelineLabel: document.querySelector("#pipelineLabel"),
    jobStatusTitle: document.querySelector("#jobStatusTitle"),
    jobStatusMessage: document.querySelector("#jobStatusMessage"),
    progressTrack: document.querySelector("#progressTrack"),
    progressBar: document.querySelector("#progressBar"),
    progressNumber: document.querySelector("#progressNumber"),
    lastUpdated: document.querySelector("#lastUpdated"),
    stageList: document.querySelector("#stageList"),
    errorPanel: document.querySelector("#errorPanel"),
    errorCode: document.querySelector("#errorCode"),
    errorStage: document.querySelector("#errorStage"),
    errorTitle: document.querySelector("#errorTitle"),
    errorMessage: document.querySelector("#errorMessage"),
    errorActionBox: document.querySelector("#errorActionBox"),
    errorAction: document.querySelector("#errorAction"),
    technicalDetails: document.querySelector("#technicalDetails"),
    errorTechnical: document.querySelector("#errorTechnical"),
    copyErrorButton: document.querySelector("#copyErrorButton"),
    downloadButton: document.querySelector("#downloadButton"),
    downloadButtonLabel: document.querySelector("#downloadButtonLabel"),
    newRequestButton: document.querySelector("#newRequestButton"),
    toast: document.querySelector("#toast"),
  };

  function updateCharacterCount() {
    const count = elements.prompt.value.length;
    const configuredLimit = Number(state.health?.prompt_max_chars);
    const fallbackLimit = Number(elements.prompt.maxLength) || 20_000;
    const limit = Number.isFinite(configuredLimit) && configuredLimit > 0
      ? configuredLimit
      : fallbackLimit;
    elements.characterCount.textContent = `${count.toLocaleString("ko-KR")} / ${limit.toLocaleString("ko-KR")}`;
    elements.prompt.removeAttribute("aria-invalid");
  }

  async function api(path, options = {}) {
    const response = await window.fetch(path, {
      ...options,
      headers: {
        Accept: "application/json",
        ...(options.body ? { "Content-Type": "application/json" } : {}),
        ...(options.headers || {}),
      },
    });

    const contentType = response.headers.get("content-type") || "";
    const payload = contentType.includes("application/json")
      ? await response.json()
      : null;

    if (!response.ok) {
      const error = payload?.error || {
        code: `HTTP_${response.status}`,
        title: "요청을 처리하지 못했습니다",
        message: `서버가 HTTP ${response.status} 응답을 반환했습니다.`,
        action: "서버 상태를 확인한 뒤 다시 시도하세요.",
        context: {},
      };
      const exception = new Error(error.message || "요청 실패");
      exception.payload = error;
      exception.status = response.status;
      throw exception;
    }
    return payload;
  }

  async function checkHealth({ restoreBusyJob = true } = {}) {
    try {
      const health = await api("/api/health");
      state.health = health;
      renderHealth(health);
      if (
        restoreBusyJob &&
        health.active_job_id &&
        (!state.currentJobId || state.currentJobId !== health.active_job_id)
      ) {
        setCurrentJob(health.active_job_id);
        await loadJob({ immediate: true });
      }
    } catch (error) {
      state.health = null;
      renderHealthError(error);
    }
    syncInputState();
  }

  function renderHealth(health) {
    elements.serverBadge.classList.remove("is-checking", "is-ready", "is-error");
    elements.readinessNotice.classList.remove("is-ready", "is-error");
    const promptLimit = Number(health.prompt_max_chars);
    if (Number.isFinite(promptLimit) && promptLimit > 0) {
      elements.prompt.maxLength = promptLimit;
      updateCharacterCount();
    }

    if (health.ready) {
      elements.serverBadge.classList.add("is-ready");
      elements.serverBadgeText.textContent = `${health.driver.label} 준비됨`;
      elements.readinessNotice.classList.add("is-ready");
      const networkText = health.network_enabled
        ? "패키지 설치용 네트워크 허용"
        : "네트워크 사용 안 함";
      elements.readinessNotice.textContent = `${health.driver.message} · ${networkText} · 배포/파괴 작업 차단`;
    } else {
      elements.serverBadge.classList.add("is-error");
      elements.serverBadgeText.textContent = "실행기 설정 필요";
      elements.readinessNotice.classList.add("is-error");
      elements.readinessNotice.textContent = `${health.driver.message} ${health.driver.action}`.trim();
    }
  }

  function renderHealthError(error) {
    elements.serverBadge.classList.remove("is-checking", "is-ready");
    elements.serverBadge.classList.add("is-error");
    elements.serverBadgeText.textContent = "서버 연결 오류";
    elements.readinessNotice.classList.remove("is-ready");
    elements.readinessNotice.classList.add("is-error");
    elements.readinessNotice.textContent =
      error?.payload?.message || "웹 서버에 연결할 수 없습니다. 서버 실행 상태를 확인하세요.";
  }

  function setCurrentJob(jobId) {
    state.currentJobId = jobId;
    if (jobId) {
      window.localStorage.setItem(STORAGE_KEY, jobId);
    } else {
      window.localStorage.removeItem(STORAGE_KEY);
    }
  }

  async function submitJob(event) {
    event.preventDefault();
    if (state.submitting || isActiveJob()) {
      return;
    }

    const prompt = elements.prompt.value.trim();
    if (!prompt) {
      elements.prompt.setAttribute("aria-invalid", "true");
      elements.prompt.focus();
      showToast("만들 앱의 목적과 핵심 기능을 입력해 주세요.");
      return;
    }
    if (!state.health?.ready) {
      showToast("먼저 코딩 에이전트 실행 환경을 설정해 주세요.");
      return;
    }

    state.submitting = true;
    syncInputState();
    elements.startButtonLabel.textContent = "시작하는 중…";

    try {
      const job = await api("/api/jobs", {
        method: "POST",
        body: JSON.stringify({ prompt }),
      });
      state.job = job;
      setCurrentJob(job.id);
      renderJob(job);
      schedulePoll(350);
      window.requestAnimationFrame(() => {
        elements.jobPanel.scrollIntoView({ behavior: "smooth", block: "start" });
      });
    } catch (error) {
      const payload = error.payload || {};
      const runningJob = payload.context?.current_job_id;
      if (runningJob) {
        setCurrentJob(runningJob);
        await loadJob({ immediate: true });
        showToast("이미 실행 중인 작업 상태로 연결했습니다.");
      } else {
        renderStandaloneError(payload);
      }
    } finally {
      state.submitting = false;
      syncInputState();
    }
  }

  function schedulePoll(delay = 1000) {
    window.clearTimeout(state.pollTimer);
    if (!state.currentJobId) {
      return;
    }
    state.pollTimer = window.setTimeout(() => loadJob({ immediate: false }), delay);
  }

  async function loadJob({ immediate = false } = {}) {
    if (!state.currentJobId) {
      return;
    }
    try {
      const job = await api(`/api/jobs/${encodeURIComponent(state.currentJobId)}`);
      state.job = job;
      renderJob(job);
      if (ACTIVE_STATUSES.has(job.status)) {
        schedulePoll(immediate ? 700 : 1100);
      } else {
        window.clearTimeout(state.pollTimer);
        await checkHealth({ restoreBusyJob: false });
      }
    } catch (error) {
      if (error.status === 404) {
        setCurrentJob(null);
        state.job = null;
        elements.jobPanel.hidden = true;
        showToast("이전에 보던 작업 기록을 찾을 수 없어 초기화했습니다.");
        syncInputState();
        return;
      }
      renderHealthError(error);
      schedulePoll(3000);
    }
  }

  function renderJob(job) {
    elements.jobPanel.hidden = false;
    if (!elements.prompt.value && job.prompt) {
      elements.prompt.value = job.prompt;
      updateCharacterCount();
    }
    const progress = Number.isFinite(job.progress) ? job.progress : 0;
    const active = ACTIVE_STATUSES.has(job.status);

    elements.jobStatusPill.textContent = job.status_label || job.status;
    elements.jobStatusPill.classList.toggle("is-completed", job.status === "completed");
    elements.jobStatusPill.classList.toggle("is-failed", job.status === "failed");
    elements.pipelineLabel.textContent = job.pipeline ? `자동 파이프라인 · ${job.pipeline}` : "";
    elements.jobStatusTitle.textContent = statusTitle(job);
    elements.jobStatusMessage.textContent = job.message || "상태를 확인하고 있습니다.";
    elements.progressNumber.textContent = String(progress);
    elements.progressBar.style.width = `${progress}%`;
    elements.progressTrack.setAttribute("aria-valuenow", String(progress));
    elements.lastUpdated.textContent = job.updated_at
      ? `업데이트 ${formatDateTime(job.updated_at)}`
      : "";

    renderStages(job.stages || [], job.active_stage);
    renderError(job.error);
    renderDownload(job.download || {}, job.status);

    elements.newRequestButton.hidden = active;
    elements.prompt.disabled = active;
    syncInputState();
  }

  function statusTitle(job) {
    if (job.status === "completed") {
      return "앱 제작이 완료되었습니다.";
    }
    if (job.status === "failed") {
      return "확인이 필요한 오류가 발생했습니다.";
    }
    if (job.status === "packaging") {
      return "다운로드 패키지를 준비하고 있습니다.";
    }
    if (job.status === "initializing" || job.status === "queued") {
      return "앱 제작을 준비하고 있습니다.";
    }
    const activeStage = (job.stages || []).find((stage) => stage.id === job.active_stage);
    return activeStage ? `${activeStage.name} 진행 중` : "앱을 만들고 있습니다.";
  }

  function renderStages(stages, activeStageId) {
    const fragment = document.createDocumentFragment();
    stages.forEach((stage, index) => {
      const item = document.createElement("li");
      item.className = "stage-row";
      item.dataset.status = stage.status || "pending";
      if (stage.id === activeStageId) {
        item.setAttribute("aria-current", "step");
      }

      const icon = document.createElement("span");
      icon.className = "stage-icon";
      icon.setAttribute("aria-hidden", "true");
      if (stage.status === "completed") {
        icon.textContent = "✓";
      } else if (stage.status === "failed") {
        icon.textContent = "!";
      } else {
        icon.textContent = String(index + 1);
      }

      const main = document.createElement("div");
      main.className = "stage-main";
      const titleLine = document.createElement("div");
      titleLine.className = "stage-title-line";
      const title = document.createElement("span");
      title.className = "stage-title";
      title.textContent = stage.name || stage.id;
      titleLine.appendChild(title);
      if (stage.kind === "system") {
        const kind = document.createElement("span");
        kind.className = "stage-kind";
        kind.textContent = "SYSTEM";
        titleLine.appendChild(kind);
      }
      const detail = document.createElement("p");
      detail.className = "stage-detail";
      detail.textContent = stage.detail || stage.description || "대기 중";
      main.append(titleLine, detail);

      const stateBox = document.createElement("div");
      stateBox.className = "stage-state";
      const stateLabel = document.createElement("strong");
      stateLabel.textContent = STATUS_LABELS[stage.status] || stage.status || "대기";
      stateBox.appendChild(stateLabel);
      if (stage.attempt > 1) {
        const attempt = document.createElement("span");
        attempt.textContent = `${stage.attempt}번째 시도`;
        stateBox.appendChild(attempt);
      }

      item.append(icon, main, stateBox);
      fragment.appendChild(item);
    });
    elements.stageList.replaceChildren(fragment);
  }

  function renderError(error) {
    if (!error) {
      elements.errorPanel.hidden = true;
      elements.technicalDetails.open = false;
      return;
    }

    elements.errorPanel.hidden = false;
    elements.errorCode.textContent = error.code || "ERROR";
    elements.errorStage.textContent = error.stage ? `· ${error.stage}` : "";
    elements.errorTitle.textContent = error.title || "작업을 완료하지 못했습니다";
    elements.errorMessage.textContent = error.message || "오류 메시지가 제공되지 않았습니다.";
    elements.errorAction.textContent = error.action || "오류 세부정보를 확인한 뒤 다시 실행하세요.";
    elements.errorActionBox.hidden = !error.action;

    const technical = error.technical || {};
    const technicalText = Object.keys(technical).length
      ? JSON.stringify(technical, null, 2)
      : "추가 기술 정보가 없습니다.";
    elements.errorTechnical.textContent = technicalText;
    elements.technicalDetails.hidden = !Object.keys(technical).length;
  }

  function renderStandaloneError(error) {
    const normalized = {
      code: error.code || "REQUEST_FAILED",
      title: error.title || "요청을 시작하지 못했습니다",
      message: error.message || "요청 처리 중 오류가 발생했습니다.",
      action: error.action || "입력과 서버 상태를 확인한 뒤 다시 시도하세요.",
      technical: error.context || {},
    };
    elements.jobPanel.hidden = false;
    elements.jobStatusPill.textContent = "요청 오류";
    elements.jobStatusPill.classList.remove("is-completed");
    elements.jobStatusPill.classList.add("is-failed");
    elements.pipelineLabel.textContent = "";
    elements.jobStatusTitle.textContent = "요청을 시작하지 못했습니다.";
    elements.jobStatusMessage.textContent = normalized.message;
    elements.progressNumber.textContent = "0";
    elements.progressBar.style.width = "0%";
    elements.progressTrack.setAttribute("aria-valuenow", "0");
    elements.stageList.replaceChildren();
    elements.lastUpdated.textContent = "";
    renderError(normalized);
    renderDownload({}, "failed");
    elements.newRequestButton.hidden = false;
    window.requestAnimationFrame(() => {
      elements.jobPanel.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  function renderDownload(download, status) {
    const available = Boolean(download.available && download.url && status === "completed");
    elements.downloadButton.classList.toggle("is-disabled", !available);
    elements.downloadButton.setAttribute("aria-disabled", available ? "false" : "true");
    if (available) {
      elements.downloadButton.href = download.url;
      const size = download.size_bytes ? ` · ${formatBytes(download.size_bytes)}` : "";
      elements.downloadButtonLabel.textContent = `소스 ZIP 다운로드${size}`;
      elements.downloadButton.removeAttribute("tabindex");
    } else {
      elements.downloadButton.href = "#";
      elements.downloadButtonLabel.textContent =
        status === "failed" ? "오류 해결 후 ZIP 다운로드" : "완료 후 ZIP 다운로드";
      elements.downloadButton.setAttribute("tabindex", "-1");
    }
  }

  function syncInputState() {
    const active = isActiveJob();
    const healthReady = Boolean(state.health?.ready);
    const disabled = state.submitting || active || !healthReady;
    elements.startButton.disabled = disabled;
    elements.prompt.disabled = active;

    if (state.submitting) {
      elements.startButtonLabel.textContent = "시작하는 중…";
    } else if (active) {
      elements.startButtonLabel.textContent = "앱 생성 중…";
    } else if (state.job?.status === "failed") {
      elements.startButtonLabel.textContent = "다시 만들기";
    } else {
      elements.startButtonLabel.textContent = "앱 만들기";
    }
  }

  function isActiveJob() {
    return Boolean(state.job && ACTIVE_STATUSES.has(state.job.status));
  }

  function startNewRequest() {
    window.clearTimeout(state.pollTimer);
    state.job = null;
    setCurrentJob(null);
    elements.jobPanel.hidden = true;
    elements.errorPanel.hidden = true;
    elements.prompt.disabled = false;
    elements.prompt.value = "";
    updateCharacterCount();
    syncInputState();
    elements.prompt.focus();
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  async function copyErrorDetails() {
    const text = [
      elements.errorCode.textContent,
      elements.errorTitle.textContent,
      elements.errorMessage.textContent,
      elements.errorAction.textContent,
      elements.errorTechnical.textContent,
    ]
      .filter(Boolean)
      .join("\n\n");
    try {
      await navigator.clipboard.writeText(text);
      showToast("오류 세부정보를 복사했습니다.");
    } catch (_error) {
      const selection = window.getSelection();
      const range = document.createRange();
      range.selectNodeContents(elements.errorTechnical);
      selection.removeAllRanges();
      selection.addRange(range);
      showToast("기술 세부정보를 선택했습니다. 복사 명령을 사용해 주세요.");
    }
  }

  function showToast(message) {
    window.clearTimeout(state.toastTimer);
    elements.toast.textContent = message;
    elements.toast.hidden = false;
    state.toastTimer = window.setTimeout(() => {
      elements.toast.hidden = true;
    }, 2800);
  }

  function formatBytes(value) {
    const bytes = Number(value);
    if (!Number.isFinite(bytes) || bytes < 0) {
      return "";
    }
    if (bytes < 1024) {
      return `${bytes.toLocaleString("ko-KR")} B`;
    }
    const units = ["KB", "MB", "GB"];
    let amount = bytes / 1024;
    let index = 0;
    while (amount >= 1024 && index < units.length - 1) {
      amount /= 1024;
      index += 1;
    }
    return `${amount.toFixed(amount >= 10 ? 1 : 2)} ${units[index]}`;
  }

  function formatDateTime(value) {
    const date = new Date(value);
    if (Number.isNaN(date.getTime())) {
      return value;
    }
    return new Intl.DateTimeFormat("ko-KR", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
    }).format(date);
  }

  elements.form.addEventListener("submit", submitJob);
  elements.prompt.addEventListener("input", updateCharacterCount);
  elements.prompt.addEventListener("keydown", (event) => {
    if ((event.ctrlKey || event.metaKey) && event.key === "Enter") {
      event.preventDefault();
      elements.form.requestSubmit();
    }
  });
  elements.downloadButton.addEventListener("click", (event) => {
    if (elements.downloadButton.getAttribute("aria-disabled") === "true") {
      event.preventDefault();
    }
  });
  elements.newRequestButton.addEventListener("click", startNewRequest);
  elements.copyErrorButton.addEventListener("click", copyErrorDetails);
  document.addEventListener("visibilitychange", () => {
    if (!document.hidden && isActiveJob()) {
      loadJob({ immediate: true });
    }
  });

  updateCharacterCount();
  checkHealth().then(async () => {
    if (state.currentJobId && !state.job) {
      await loadJob({ immediate: true });
    }
  });
})();
