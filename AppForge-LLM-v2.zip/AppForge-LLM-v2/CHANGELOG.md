# Changelog

## 0.2.0 — 2026-06-26

- Added the minimal single-flow `appforge web` user experience.
- Added automatic driver readiness, pipeline routing, and one-active-job control.
- Added per-stage pending/running/validating/retrying/completed/failed status reporting.
- Added structured runner events and detailed failure payloads with redacted agent output and failed gates.
- Added persisted web-job state and refresh recovery.
- Added verified ZIP download activation only after full pipeline completion.
- Added responsive, accessible, dependency-free browser UI with no external assets.
- Added FastAPI integration and end-to-end web tests.

## 0.1.0 — 2026-06-25

- Initial OpenAppForge release.
- Twelve software production pipelines.
- Repository-native stage skills and assistant adapters.
- Codex, Claude Code, and generic command drivers.
- Schema-validated artifacts, deterministic gates, retries, approvals, and checkpoints.
- Safety-controlled tools for quality, security, compliance, and release packaging.
- One-command `appforge forge` workflow and manual agent-native loop.
