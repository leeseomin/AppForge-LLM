# AppForge-LLM v2

**앱 설명 한 번으로 요구사항 정리부터 검증된 소스 ZIP 다운로드까지 진행하는 미니멀 웹앱입니다.**

[English](README.md) · [웹앱 상세](docs/WEB_APP.md) · [아키텍처](docs/ARCHITECTURE.md) · [안전 모델](docs/SAFETY.md) · [에이전트 실행 규약](AGENT_GUIDE.md)

AppForge-LLM v2는 기존 OpenAppForge의 12개 소프트웨어 제작 파이프라인과 검증 게이트를 유지하면서, 사용자가 여러 명령과 옵션을 조합하지 않아도 되도록 실행 경험을 하나로 통합했습니다.

```text
앱 설명 입력 → 앱 만들기 → 단계별 상태 확인 → 완료된 소스 ZIP 다운로드
```

![AppForge-LLM v2 미니멀 웹 UI](docs/appforge-v2-preview.png)

웹 UI가 자동으로 파이프라인을 선택하고 프로젝트를 준비한 뒤, 코딩 에이전트 실행·산출물 검증·테스트·빌드·보안 점검·릴리스 준비·안전한 압축을 순서대로 처리합니다.

## 가장 쉬운 실행 방법

필수 조건은 Python 3.11 이상과 다음 실행기 중 하나입니다.

- Codex CLI
- Claude Code CLI
- `APPFORGE_AGENT_CMD`로 연결한 사용자 정의 코딩 에이전트

```bash
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
python -m pip install dist/openappforge-0.2.0-py3-none-any.whl

appforge web
```

소스를 직접 수정하며 실행할 때는 wheel 설치 대신 `python -m pip install -e .`을 사용합니다.

기본 브라우저에서 `http://127.0.0.1:8787`이 열립니다. 이후에는 화면에서 다음 한 흐름만 사용합니다.

1. 만들 앱을 자연어로 설명합니다.
2. **앱 만들기**를 누릅니다.
3. 실행 환경 확인부터 다운로드 준비까지 각 단계의 상태를 확인합니다.
4. 모든 필수 검증이 통과하면 **소스 ZIP 다운로드** 버튼이 자동으로 활성화됩니다.

브라우저를 새로고침해도 현재 작업 ID를 복원합니다. 웹 서버가 실행 중 종료되면 해당 작업은 상세 오류와 함께 중단 상태로 기록되고, 이미 생성된 프로젝트 작업공간은 보존됩니다.

## v2 UX 개선점

- **단일 입력·단일 실행:** 파이프라인, 모드, 승인 방식과 드라이버 선택을 UI에서 제거하고 안전한 자동값을 사용합니다.
- **미니멀 단일 화면:** 요청 입력, 전체 진행률, 단계 상태, 오류, 다운로드를 한 화면에서 처리합니다.
- **단계별 실시간 상태:** 대기, 실행 중, 검증 중, 자동 재시도, 완료, 실패 상태가 각 단계에 표시됩니다.
- **자세한 오류:** 오류 코드, 실패 단계, 사용자용 설명, 해결 방법, 에이전트 출력·종료 코드·실패한 게이트를 접이식 기술 정보로 제공합니다.
- **안전한 다운로드:** 완료 전에는 버튼이 비활성화되고, 완성된 ZIP의 형식과 내부 손상을 검사한 뒤에만 활성화됩니다.
- **작업 복원:** 작업 상태를 `.appforge-web/jobs/`에 저장해 새로고침 시 이어서 표시합니다.
- **한 번에 하나의 작업:** 로컬 자원 충돌과 혼란을 막기 위해 동시에 하나의 앱만 생성합니다.

## 코딩 에이전트 설정

### 자동 선택

기본값 `APPFORGE_DRIVER=auto`는 Codex CLI를 먼저 찾고, 없으면 Claude Code CLI를 사용합니다. 웹 화면 상단에서 준비 상태를 확인할 수 있습니다.

### 사용자 정의 에이전트

```bash
APPFORGE_DRIVER=generic \
APPFORGE_AGENT_CMD='my-agent --workspace {workspace} --prompt {prompt_file}' \
appforge web
```

사용 가능한 치환자는 `{workspace}`, `{prompt_file}`, `{result_file}`, `{stage}`, `{attempt}`입니다. `{prompt_file}`을 사용하지 않으면 단계 작업 패킷이 표준입력으로 전달됩니다.

### 주요 환경 변수

```text
APPFORGE_PROJECTS_DIR          생성 프로젝트 경로, 기본값 projects/
APPFORGE_DATA_DIR              웹 작업 상태 경로, 기본값 .appforge-web/
APPFORGE_DRIVER                auto | codex | claude | generic
APPFORGE_AGENT_CMD             generic 실행 명령 템플릿
APPFORGE_MODEL                 드라이버에 전달할 모델 이름
APPFORGE_ALLOW_NETWORK         기본값 true, 패키지 설치·원격 감사 허용
APPFORGE_STAGE_TIMEOUT         단계별 제한 시간(초), 기본값 3600
APPFORGE_MAX_STAGE_ATTEMPTS    단계별 최대 자동 시도 횟수
APPFORGE_MAX_TURNS             Claude Code 최대 턴 수
APPFORGE_UNSAFE_AGENT          기본값 false, 격리 환경 외 사용 금지
```

웹앱의 전체 설정과 API는 [docs/WEB_APP.md](docs/WEB_APP.md)에 정리되어 있습니다.

## 진행 단계와 결과 위치

요청에 따라 12개 파이프라인 중 하나가 자동 선택됩니다. 예를 들어 웹앱은 다음 순서로 진행됩니다.

```text
실행 환경 확인
→ 프로젝트 준비
→ 요청 정리
→ 기능 명세
→ 구조 설계
→ UX 설계
→ 앱 구현
→ 테스트·빌드
→ 보안 점검
→ 릴리스 점검
→ 인계 준비
→ 다운로드 준비
```

생성된 프로젝트는 `projects/<프로젝트명>-<작업ID>/`에 저장됩니다.

```text
프로젝트/
├── 실제 앱 소스
└── .appforge/
    ├── project.json          요청, 파이프라인, 안전 정책
    ├── state.json            현재·완료 단계
    ├── artifacts/            스키마 검증된 산출물
    ├── checkpoints/          단계별 원자적 체크포인트
    ├── prompts/              에이전트에 전달한 작업 패킷
    ├── logs/                 시도별 에이전트·검증 기록
    └── reports/              SBOM, 인벤토리, 최종 소스 ZIP
```

최종 ZIP에서는 `.env`, 개인키, 자격증명, Git 데이터, 의존성, 캐시와 `.appforge/` 내부 실행 기록을 제외합니다.

## 안전 기본값

웹앱은 목표 달성에 필요한 의존성 설치를 위해 네트워크를 기본 허용하지만 다음 작업은 자동 승인하지 않습니다.

- 외부 배포 또는 패키지 게시
- Git push
- 유료 자원 생성
- 운영 데이터 변경
- 파괴적 파일·인프라 작업
- 에이전트 권한 샌드박스 우회

`APPFORGE_ALLOW_NETWORK=false`로 네트워크 의존 도구를 끌 수 있습니다. 테스트와 빌드 스크립트는 생성된 저장소 코드를 실행하므로 신뢰할 수 없는 요청은 컨테이너나 가상머신에서 실행해야 합니다.

“완료”는 실제 구현, 필수 산출물, 실행된 테스트·빌드 증거, 보안 검토, 재현 가능한 시작 절차와 소스 ZIP 생성까지 성공했다는 뜻입니다. 외부 서비스에 배포되었다는 뜻은 아닙니다.

## 기존 CLI 호환성

v2의 권장 UX는 `appforge web`이지만 기존 CLI와 에이전트 네이티브 흐름도 유지됩니다.

```bash
appforge forge "반응형 개인 예산 웹앱을 만들어라" --driver auto --allow-network
appforge run <project>
appforge status <project>
appforge prompt <project>
appforge complete <project>
appforge doctor
appforge tool list
```

기존 저장소 변경은 CLI에서 계속 지원합니다.

```bash
cd existing-project
appforge forge "기존 로그인을 유지하면서 패스키 로그인을 추가하라" \
  --target . --driver auto --allow-network
```

## 내장 제작 시스템

- **12개 파이프라인:** 웹앱, 풀스택 SaaS, API, CLI, 데스크톱, 모바일, 데이터 앱, 자동화, 라이브러리/SDK, 프로토타입, 기능 추가, 버그 수정
- **55개 이상 스킬:** 단계별 플레이북, 기술 스택, 도메인, 실패 복구, 리뷰, 보안 경계, 완료 정의
- **20개 이상 도구:** 저장소 분석, 제한된 파일 작업, 테스트·린트·타입·빌드, 비밀정보 검사, 취약점 감사, SBOM, 릴리스 준비, 안전한 압축
- **22개 JSON 스키마:** 제품 정의, 요구사항, 아키텍처, UX, API·데이터 계약, 구현, 검증, 보안, 운영, 릴리스, 인계와 회귀 보고서

## 개발 및 검증

```bash
python -m pip install -e '.[dev]'
python -m compileall -q appforge tests
node --check appforge/resources/web/app.js
python -m pytest
python -m build
```

## 라이선스와 영감

AppForge-LLM v2/OpenAppForge는 Apache License 2.0으로 제공되는 독립적인 원본 구현입니다. 선언형 파이프라인, 조합 가능한 스킬, 자동 발견 도구, 체크포인트와 리뷰 게이트를 저장소 중심으로 결합하는 접근은 OpenMontage에서 영감을 받았습니다. OpenMontage 소스 코드는 포함하지 않았습니다. 자세한 내용은 [ATTRIBUTION.md](ATTRIBUTION.md)에 기록했습니다.
