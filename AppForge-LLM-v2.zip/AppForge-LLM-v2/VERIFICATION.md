# Verification record

Date: 2026-06-26  
Version: 0.2.0

## Automated checks

- `PYTEST_DISABLE_PLUGIN_AUTOLOAD=1 PYTHONPATH=. python -m pytest -q` — **21 passed**.
- Deterministic web-job integration run — **7/7 prototype stages completed**, followed by archive validation, HTTP ZIP download, ZIP integrity testing, and confirmation that `.appforge/` runtime state was excluded.
- Detailed failure-path integration — missing agent setup and agent exit code `7` were preserved as structured, actionable web errors with failed-stage and validation context.
- Headless Chromium UI journey with mocked API — request submission, progress rendering, per-stage completion, `0 → 100%` transition, and disabled-to-enabled ZIP button behavior passed.
- `node --check appforge/resources/web/app.js` — passed.
- `python -m compileall -q appforge tests` — passed.
- `python -m pip wheel . --no-deps --no-build-isolation -w dist` — wheel built successfully and contains all three web assets.
- Wheel installed into an isolated target — version, root page, JavaScript asset, and `/api/health` smoke checks passed.
- Framework self secret scan — no findings.
- Live Uvicorn health smoke check — passed; settled idle CPU sample was zero process ticks over three seconds.

## Shipped production surface

- Pipelines: 12
- Auto-discovered tools: 25
- Markdown skills: 56
- Artifact schemas: 22
- Browser assets: 3, with no external runtime assets
- Web API: health, job creation, job status, verified ZIP download
- Built wheel: `openappforge-0.2.0-py3-none-any.whl`
- Wheel SHA-256: `59f23f613e649068467eb2513942eec5f66535451b2fb001b7f6f561c1feebda`

## Environment limitation

Codex CLI and Claude Code CLI were not installed in the build environment, so live vendor-model executions were not performed. Their existing adapters remain covered by unit/construction checks. The generic driver was exercised end to end through the complete web workflow, including stage events, tests, packaging, download, and detailed error propagation.
