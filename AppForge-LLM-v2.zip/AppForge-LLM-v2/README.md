# AppForge-LLM v2

**Describe an app once, watch every production stage, and download the verified source as a ZIP.**

[한국어 문서](README.ko.md) · [Web app guide](docs/WEB_APP.md) · [Architecture](docs/ARCHITECTURE.md) · [Safety](docs/SAFETY.md) · [Agent Guide](AGENT_GUIDE.md)

AppForge-LLM v2 keeps OpenAppForge's twelve production pipelines and deterministic gates, but replaces the option-heavy primary workflow with one focused browser journey:

```text
Describe the app → Build → Follow stage status → Download the completed source ZIP
```

![AppForge-LLM v2 minimal web UI](docs/appforge-v2-preview.png)

The server automatically selects a pipeline, initializes an isolated workspace, invokes the coding agent, validates structured artifacts, runs tests/build/security/release checks, and exposes the archive only after the complete pipeline passes.

## Fastest start

Prerequisites: Python 3.11+ and one of the following:

- Codex CLI
- Claude Code CLI
- a custom coding-agent command configured through `APPFORGE_AGENT_CMD`

```bash
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
python -m pip install dist/openappforge-0.2.0-py3-none-any.whl

appforge web
```

Use `python -m pip install -e .` instead when developing the framework from source.

The default browser opens `http://127.0.0.1:8787`. From that point there is one workflow:

1. Enter the application request.
2. Select **Build app**.
3. Follow every stage from environment checks through archive preparation.
4. Download the source ZIP when all required gates pass.

The browser restores the active job after refresh. Job state is persisted under `.appforge-web/jobs/`. If the server stops during a run, that job is marked interrupted with a detailed error while its project workspace remains intact.

## v2 UX changes

- **One input and one action:** pipeline, driver, mode, and approval choices are resolved by safe defaults rather than exposed as routine UI decisions.
- **Single minimal screen:** request, overall progress, stage status, errors, and download all live together.
- **Stage-level status:** pending, running, validating, automatically retrying, completed, and failed states are visible for every step.
- **Actionable errors:** the UI shows an error code, failed stage, plain-language explanation, recommended action, and expandable technical data including agent output, exit codes, and failed gates.
- **Verified download state:** the button stays disabled until the source archive exists and passes ZIP integrity checks.
- **Refresh recovery:** the current job ID is restored in the browser and status is persisted by the server.
- **One active build:** only one job runs at a time to avoid local resource conflicts and ambiguous output.

## Coding-agent setup

### Automatic selection

The default `APPFORGE_DRIVER=auto` selects Codex CLI first and then Claude Code CLI. Readiness appears at the top of the web page before the build button is enabled.

### Custom agent command

```bash
APPFORGE_DRIVER=generic \
APPFORGE_AGENT_CMD='my-agent --workspace {workspace} --prompt {prompt_file}' \
appforge web
```

Available placeholders are `{workspace}`, `{prompt_file}`, `{result_file}`, `{stage}`, and `{attempt}`. When `{prompt_file}` is omitted, the full stage packet is sent on standard input.

### Main environment variables

```text
APPFORGE_PROJECTS_DIR          generated project directory; default projects/
APPFORGE_DATA_DIR              persisted web-job state; default .appforge-web/
APPFORGE_DRIVER                auto | codex | claude | generic
APPFORGE_AGENT_CMD             generic command template
APPFORGE_MODEL                 model passed to the selected driver
APPFORGE_ALLOW_NETWORK         default true for installs and remote audits
APPFORGE_STAGE_TIMEOUT         per-stage timeout in seconds; default 3600
APPFORGE_MAX_STAGE_ATTEMPTS    optional maximum automatic attempts per stage
APPFORGE_MAX_TURNS             optional Claude Code turn limit
APPFORGE_UNSAFE_AGENT          default false; isolated environments only
```

See [docs/WEB_APP.md](docs/WEB_APP.md) for configuration and API details.

## Stages and output

The request is routed to one of twelve pipelines. A typical web-app run appears as:

```text
Environment check
→ Project setup
→ Intake
→ Specification
→ Architecture
→ Experience design
→ Implementation
→ Tests and build
→ Security
→ Release readiness
→ Handoff
→ Download preparation
```

Projects are created under `projects/<project-name>-<job-id>/`.

```text
project/
├── generated application source
└── .appforge/
    ├── project.json          request, pipeline, and safety policy
    ├── state.json            current and completed stages
    ├── artifacts/            schema-validated production evidence
    ├── checkpoints/          atomic stage records
    ├── prompts/              exact coding-agent packets
    ├── logs/                 per-attempt agent and validation records
    └── reports/              SBOM, inventories, and final source ZIP
```

The final archive excludes `.env` files, private keys, credentials, VCS state, dependencies, caches, and `.appforge/` runtime internals.

## Safety defaults

The web workflow enables network-dependent installation and audit tools by default so generated applications can be built and tested. It still does not authorize:

- deployment or package publishing;
- Git push;
- paid-resource creation;
- production-data changes;
- destructive workspace or infrastructure operations;
- coding-agent permission-sandbox bypass.

Set `APPFORGE_ALLOW_NETWORK=false` to disable network-dependent AppForge tools. Tests and build scripts execute generated repository code, so isolate untrusted requests in a container or virtual machine.

“Complete” means implemented behavior, required structured artifacts, executed test/build evidence, security review, reproducible quickstart guidance, and a valid source archive. It does not mean external deployment occurred.

## Existing CLI compatibility

`appforge web` is the recommended v2 experience, while the full CLI and repository-native agent loop remain available:

```bash
appforge forge "Build a responsive personal budget app" --driver auto --allow-network
appforge run <project>
appforge status <project>
appforge prompt <project>
appforge complete <project>
appforge doctor
appforge tool list
```

Existing-repository changes remain available through the CLI:

```bash
cd existing-project
appforge forge "Add passkey login while preserving password login" \
  --target . --driver auto --allow-network
```

## Production system

- **12 pipelines:** web app, full-stack SaaS, API service, CLI, desktop, mobile, data app, automation, library/SDK, prototype, feature, and bugfix.
- **55+ skills:** stage playbooks, stack and domain guidance, failure recovery, review, safety boundaries, and definition of done.
- **20+ auditable tools:** repository inspection, bounded file operations, tests, lint, type checks, build, secret scanning, dependency audit, SBOM, readiness, and safe archiving.
- **22 JSON schemas:** product, requirements, architecture, UX, API/data contracts, implementation, verification, security, operations, release, handoff, diagnosis, and regression evidence.

## Development and verification

```bash
python -m pip install -e '.[dev]'
python -m compileall -q appforge tests
node --check appforge/resources/web/app.js
python -m pytest
python -m build
```

## License and inspiration

AppForge-LLM v2/OpenAppForge is original software released under the Apache License 2.0. Its repository-native combination of declarative pipelines, composable skills, auto-discovered tools, checkpoints, and review gates was inspired by OpenMontage. No OpenMontage source code is included. See [ATTRIBUTION.md](ATTRIBUTION.md).
