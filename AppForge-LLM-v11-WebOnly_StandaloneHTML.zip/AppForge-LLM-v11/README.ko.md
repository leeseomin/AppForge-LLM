# AppForge-LLM v11

**어떤 형태의 앱을 요청해도 브라우저 웹앱으로 구현하고, 전체 소스와 더블클릭 실행용 단일 HTML을 함께 제공하는 AI 앱 빌더입니다.**

[English](README.md) · [v11 릴리스 노트](V11_RELEASE_NOTES.md) · [웹앱 상세](docs/WEB_APP.md) · [아키텍처](docs/ARCHITECTURE.md) · [안전 모델](docs/SAFETY.md) · [변경 기록](CHANGELOG.md)

v11은 사용자가 말한 앱의 **사용 감각**과 실제 **배포 대상**을 분리합니다. 모바일 앱은 터치 우선 반응형 웹앱, 데스크톱 앱은 패널·단축키 중심 브라우저 작업공간, CLI는 터미널형 웹 UI, API 서비스는 요청 빌더와 로컬 데모 어댑터를 갖춘 웹앱으로 변환합니다. 새 프로젝트의 공개 파이프라인은 `web-app-lite`와 `web-app`뿐이며, 수정 작업은 `feature` 또는 `bugfix`를 사용하되 웹 배포 계약을 계속 유지합니다.

```text
앱 설명 → 브라우저 UX 적응 → 전체 웹앱 구현·검증
→ 00_START_HERE.html 생성 → file:// 실행 검사 → 최종 ZIP 재검증
```

## v11의 완료 조건

소스 생성이나 일반 빌드만 성공해서는 완료되지 않습니다. 다음 조건이 모두 통과해야 다운로드가 활성화됩니다.

- 유지보수 가능한 전체 브라우저 웹앱 소스
- `.appforge/deliverables/00_START_HERE.html` 생성
- 로컬 CSS·JS·이미지·폰트·초기 데이터 인라인
- 미해결 자산, 외부 런타임 URL, `localhost`, 동적 청크, 비밀정보 검사
- 필수 외부 네트워크를 차단한 브라우저 시작 스모크 테스트
- 단일 HTML SHA-256과 배포 manifest 일치
- 최종 ZIP을 다시 열어 루트 파일·경로 안전성·해시 재검증

최종 ZIP 구조는 초보자용 실행 파일과 개발자용 소스를 분리합니다.

```text
my-app-webapp.zip
├── 00_START_HERE.html       # 더블클릭 실행
├── README_FIRST.md          # 1분 실행 안내
├── DELIVERY.json            # 모드·검증·해시·제약
├── source/                  # 유지보수 가능한 전체 웹앱 소스
└── web-build/               # 선택적 정적 호스팅 빌드
```

실제 인증·결제·이메일·비밀 API·멀티테넌트 DB처럼 서버가 필요한 기능은 단일 HTML에서 성공한 것처럼 위장하지 않습니다. 단일 파일은 명확히 표시된 `local-demo` 또는 시뮬레이션으로 동작하고, 실제 배포용 어댑터는 `source/`에 남깁니다.

## 주요 기능

- 외부 LLM 프로바이더와 로컬 Bun 브릿지 연결
- 완전 자율 실행 또는 승인 체크포인트 모드
- 작업 대기열, 재시도, 취소, 후속 수정, 산출물·코드 열람
- 모바일·데스크톱·CLI·API·게임 의도를 보존하는 웹 전용 라우팅
- 결정론적 `build_standalone_html`, `validate_web_delivery`, `package_web_delivery` 도구
- 완료 화면 첫 버튼 **바로 실행 HTML 받기**, 두 번째 버튼 **전체 웹앱 ZIP 받기**
- 배포 생성 후 검증된 standalone을 우선 사용하는 프리뷰
- ZIP 경로 순회·심볼릭 링크·중복 파일명·비밀 파일·manifest 불일치 차단

AppForge는 생성 앱을 자동 배포하거나 운영 데이터를 변경하지 않습니다.

## 가장 쉬운 실행 방법

필수 조건은 Python 3.11 이상, Node.js/npm, Bun, 외부 LLM 계정 또는 API 키입니다.

```bash
./build.sh
```

기본 웹 UI는 `http://127.0.0.1:8787`, 브릿지는 `http://127.0.0.1:8788`입니다. 상단 **LLM 연결**에서 프로바이더와 모델을 설정한 뒤 앱을 설명합니다.

빌드된 wheel 사용:

```bash
python -m venv .venv
source .venv/bin/activate              # Windows: .venv\Scripts\activate
python -m pip install dist/openappforge-0.11.0-py3-none-any.whl
appforge web
```

소스에서 실행:

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
npm --prefix frontend install
npm --prefix frontend run build
appforge web
```

## 개발 및 검증

```bash
python -m compileall -q appforge tests
python -m pytest
npm --prefix frontend run build
(cd llm_bridge && bun run typecheck && bun test)
python -m pip wheel . --no-deps --no-build-isolation -w dist
```

프런트엔드 개발은 API와 Vite를 각각 실행합니다.

```bash
appforge web --no-browser
npm --prefix frontend run dev
```

## 주요 환경 변수

```text
APPFORGE_PROJECTS_DIR          생성 프로젝트 경로, 기본값 projects/
APPFORGE_DATA_DIR              웹 작업 상태, 기본값 .appforge-web/
APPFORGE_LLM_BRIDGE_URL        브릿지 URL, 기본값 http://127.0.0.1:8788
APPFORGE_ALLOW_NETWORK         패키지 설치·원격 감사 허용, 기본값 false
APPFORGE_ALLOW_DESTRUCTIVE     파괴적 도구 허용, 기본값 false
APPFORGE_STAGE_TIMEOUT         단계별 제한 시간
APPFORGE_MAX_STAGE_ATTEMPTS    단계별 최대 자동 시도 횟수
APPFORGE_PROMPT_MAX_CHARS      요청 입력 제한, 기본값 20000
```

## 라이선스와 영감

AppForge-LLM v11/OpenAppForge는 Apache License 2.0으로 제공되는 독립적인 원본 구현입니다. 자세한 내용은 [ATTRIBUTION.md](ATTRIBUTION.md)에 기록했습니다.
