# Verification report

Date: 2026-08-08  
Version: 0.11.0

## Scope

This report covers the v11 web-only routing contract, standalone HTML generation and validation, final web delivery packaging, API/CLI enforcement, revision freshness, and the standalone-first completion UI.

## Commands and results

### Python regression suite

The test files were run in bounded groups to avoid one long-lived test process masking teardown problems.

```bash
python -m pytest -q tests/test_pipelines.py tests/test_projects_and_checkpoints.py tests/test_prompting.py tests/test_tools.py
python -m pytest -q tests/test_web.py
python -m pytest -q tests/test_runner.py
python -m pytest -q \
  tests/test_agent_budget_recovery.py \
  tests/test_app_code_merge_script.py \
  tests/test_artifact_schemas.py \
  tests/test_cli.py \
  tests/test_cli_auth.py \
  tests/test_json_extract.py \
  tests/test_llm_auth.py \
  tests/test_llm_bridge.py
```

Result: **144 tests passed**.

Coverage includes:

- greenfield requests resolving only to `web-app-lite` or `web-app`;
- legacy public pipeline names being normalized while preserving adaptation intent;
- project delivery contract creation and migration;
- normal and repair prompts receiving the same web delivery contract;
- standalone CSS, JavaScript, image, font, and CSS URL inlining;
- external dependency, localhost, dynamic chunk, secret, path traversal, symlink, duplicate name, and hash mismatch rejection;
- browser smoke evidence, manifest generation, root ZIP entries, and `source/` mapping;
- direct standalone download, final webapp ZIP download, retry, guided approval, preview, and stale-revision exclusion;
- the retained production UI receiving the v11 standalone-first overlay.

### Python and JavaScript syntax validation

```bash
python -m compileall -q appforge tests
node --check appforge/resources/web/v11-delivery-overlay.js
node --check frontend/public/v11-delivery-overlay.js
```

Result: passed.

The globally available TypeScript parser was also run over every `frontend/src/**/*.ts` file and every Vue `<script>` block. Result: passed with no parse diagnostics.

### Browser UI overlay smoke

The v11 overlay was executed in system Chromium against a representative completed-job DOM with a mocked job response.

Verified:

- title upgraded to `AppForge-LLM v11`;
- web-only contract note and `00_START_HERE.html` guidance inserted;
- legacy pipeline text converted to a browser UX adaptation label;
- exactly one **바로 실행 HTML 받기** action and one **전체 웹앱 ZIP 받기** action remained after repeated DOM observation;
- file sizes and `local-demo` limitations rendered;
- no uncaught page errors occurred.

This environment has a managed Chromium URL blocklist that rejects both HTTP and `file://` navigation with `ERR_BLOCKED_BY_ADMINISTRATOR`. The delivery validator therefore first attempts real `file://` navigation and permits its strict same-document, network-blocked browser fallback only when that exact managed-policy failure is observed and recorded.

### Python package build

```bash
python -m pip wheel . --no-deps --no-build-isolation -w /tmp/appforge-v11-wheel-final
```

Result: `openappforge-0.11.0-py3-none-any.whl` built successfully.

Wheel checks confirmed inclusion of:

- `appforge/delivery.py`;
- `appforge/tooling/tools/web_delivery.py`;
- `web_delivery_manifest.schema.json`;
- web delivery meta/stage skills;
- the packaged v11 UI overlay.

Final wheel SHA-256 at verification time:

```text
b7d4634b14bc32b0b5670dd74d829763a95597d095b806ae750ca8b00803c1e2
```

## Environment limitations

A fresh npm install could not be completed because the execution environment's internal npm mirror returned HTTP 404 for required packages, including `zwitch` during the frontend attempt and `@smithy/eventstream-codec` during the bridge attempt. Consequently, a fresh Vue production build and Bun bridge typecheck were not claimed in this report.

The editable frontend source changes are included and passed TypeScript syntax parsing. The previously packaged production bundle is retained and supplemented by the tested v11 overlay, which is served by an explicit FastAPI route and covered by Python and browser-DOM regression checks.
