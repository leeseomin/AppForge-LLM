# Architecture

## Design objective

AppForge-LLM v11 turns natural-language software requests into browser-first web applications. Model reasoning stays at the edge, while routing, delivery policy, executable gates, validation, and packaging remain deterministic and resumable.

## Web-only delivery invariant

Every new public request resolves to `web-app-lite` or `web-app`. Existing repositories use `feature` or `bugfix`, but inherit the same web delivery contract. Words such as mobile, desktop, CLI, API, automation, or SDK determine an adaptation profile, not a non-web deployment target.

Each project records this invariant in `project.json`:

```text
delivery.target == "web"
delivery.browser_first == true
delivery.standalone_html.required == true
```

The public API and CLI normalize legacy pipeline names instead of allowing them to bypass the invariant.

## Web interaction layer

- `appforge.web` serves the local Vue interface and narrow job API.
- `appforge.web_jobs.JobManager` persists server-owned job state and maps runner events to user-facing stages.
- The visible sequence includes `preflight`, `project_setup`, the selected production pipeline, and the deterministic `web_delivery_package` system step.
- A job is not marked completed until both the validated standalone HTML and validated web delivery archive exist.
- The standalone endpoint exposes only the verified `00_START_HERE.html`; the ZIP endpoint exposes only the verified `*-webapp.zip` package.

The retained production UI bundle is supplemented by the v11 delivery overlay so existing installations receive the web-only notice, standalone-first download action, and local-demo limitations. The editable Vue source contains the same behavior for the next normal frontend build.

## Control plane

The control plane consists of seven layers:

1. **Request classifier** — identifies complexity, requested shape, and adaptation profile. Application code, not the LLM, selects the effective public pipeline.
2. **Project delivery contract** — stores the immutable web target and standalone/archive requirements.
3. **Pipeline manifest** — orders stages and declares artifacts, tools, review criteria, approvals, attempts, and executable gates.
4. **Stage packet compiler** — combines skills, the normalized request, validated artifacts, repository context, schemas, tool contracts, and prior failure findings.
5. **LLM bridge drivers** — stream model/tool activity while Python executes file and command tools and validates all submitted evidence.
6. **Engineering memory layer** — records compact decisions, outcomes, and repeated-failure signatures.
7. **Gate/checkpoint engine** — validates completion records and schemas, executes required tools, performs deterministic review, and atomically records the result.

The next stage is calculated from checkpoints rather than conversational memory.

## Web delivery plane

The mandatory `web_delivery` stage uses three deterministic tools:

- `build_standalone_html` builds or locates the web build, inlines local scripts, styles, images, fonts, and supported worker assets, and writes `.appforge/deliverables/00_START_HERE.html`.
- `validate_web_delivery` checks document structure, unresolved assets, external runtime dependencies, localhost/WebSocket requirements, dynamic chunks, secrets, file-protocol behavior, visible output, console failures, and network isolation.
- `package_web_delivery` creates `README_FIRST.md`, `DELIVERY.json`, and a final archive whose root contains `00_START_HERE.html`, with maintainable project files mapped under `source/` and an optional static build under `web-build/`.

The archive is reopened after creation. Paths, duplicate/case-colliding names, symbolic links, manifest hashes, required root entries, and source presence are verified again before download is enabled.

## Standalone modes

- **Full** — the core application works entirely from the single HTML file.
- **Local demo** — the same browser UI and core journey run locally while real authentication, payment, email, private APIs, or server persistence remain explicitly simulated or unavailable. Limitations are recorded in both the interface and `DELIVERY.json`.

This distinction keeps the always-provided HTML honest instead of pretending that server-only behavior succeeded.

## Data plane and completion invariant

A project owns a `.appforge/` control directory. JSON is durable machine-readable state, Markdown is operating knowledge, and YAML is pipeline policy.

```text
A job is complete only when:
  every required pipeline stage succeeded
  AND full web build evidence passed
  AND standalone HTML was created
  AND standalone static and browser validation passed
  AND file-protocol/network-isolation evidence passed
  AND the web delivery archive was created
  AND archive structure and manifest hashes passed
```

A revision never copies an old standalone file, delivery manifest, user README, delivery ZIP, or `.appforge/deliverables/`; they are regenerated from the revised source.

## Pipeline anatomy

A manifest stage includes:

- `name`, `description`, and a Markdown skill;
- `produces`, the required artifact schema names;
- `tools`, which are visible to the coding agent;
- `gates`, which the orchestrator executes;
- `review_focus` and `success_criteria`;
- `approval`, used in guided mode.

Tools listed under `tools` are affordances; tools under `gates` are enforcement. The web delivery contract is injected into both normal and repair prompts so retries cannot silently drop it.

## Failure and recovery

Each stage has a bounded attempt count. Failures retain the exact prompt, captured driver output, completion/artifact/gate records, deterministic findings, and checkpoint. Repeated failure signatures trigger the loop guard. Web delivery failures use distinct error codes for missing or invalid standalone files, external runtime dependencies, file-protocol smoke failures, archive validation failures, and manifest mismatches.

## Extension boundaries

- Add workflow variation as a pipeline manifest.
- Add reasoning guidance as a Markdown skill.
- Add structured evidence as a JSON schema.
- Add deterministic capability as a `Tool` subclass.
- Add an assistant/provider integration as an `AgentDriver` subclass.

Keeping those concerns separate prevents prompt wording from being mistaken for product guarantees.
