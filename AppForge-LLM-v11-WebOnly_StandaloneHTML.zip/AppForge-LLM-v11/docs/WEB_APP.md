# AppForge-LLM v11 Web Application

The v11 web application is the primary AppForge product surface. It accepts any app-shaped request, preserves the requested interaction style as a browser adaptation profile, and always delivers a browser web application with a validated single-file companion.

## Start

```bash
python -m pip install dist/openappforge-0.11.0-py3-none-any.whl
appforge web
```

From a source checkout:

```bash
./build.sh
```

The launcher prepares the Python environment, installs and builds the Vue frontend when needed, starts or reuses the local Bun LLM bridge, starts FastAPI, and opens `http://127.0.0.1:8787`.

Useful variants:

```bash
./build.sh --no-open
./build.sh --check
APPFORGE_SKIP_INSTALL=1 APPFORGE_SKIP_FRONTEND_BUILD=1 ./build.sh --smoke
appforge web --host 127.0.0.1 --port 8787 --no-browser
```

## Browser-only routing

Public clients no longer choose a native delivery pipeline.

| Original request shape | Browser adaptation |
|---|---|
| iOS, Android, Flutter, React Native | touch-first responsive web app or PWA-style UX |
| Electron, Tauri, desktop app | desktop-style browser workspace with panels, menus, drag-and-drop, and shortcuts |
| CLI or terminal tool | terminal-style web UI with command/options forms, logs, and exports |
| REST, GraphQL, API service | browser request workbench plus truthful local-demo adapter |
| automation or bot | workflow builder, simulator, and execution history UI |
| SDK or library | browser playground and documentation UI |
| data or ETL | browser file import, local processing, dashboard, and export |
| game | browser game with required assets included in the standalone core journey |

Greenfield jobs resolve only to `web-app-lite` or `web-app`. Existing-project changes use `feature` or `bugfix` while inheriting `delivery.target = "web"`. Legacy pipeline YAML files remain loadable only for old checkpoints and internal compatibility.

## Delivery lifecycle

```text
request classification
  → project delivery contract
  → full browser app implementation and checks
  → standalone build
  → 00_START_HERE.html generation
  → static audit
  → browser smoke with required network access blocked
  → DELIVERY.json and README_FIRST.md
  → source/ and optional web-build/ packaging
  → archive re-open and hash/path validation
  → completed
```

A job does not become `completed` until all delivery steps pass. Failure to create or validate the standalone entry blocks both direct HTML and ZIP download.

## Final ZIP

```text
<project>-webapp.zip
├── 00_START_HERE.html
├── README_FIRST.md
├── DELIVERY.json
├── source/
└── web-build/        # optional
```

`00_START_HERE.html` is written first at the archive root. `DELIVERY.json` records the mode (`full` or `local-demo`), SHA-256, byte size, file-protocol support, external runtime request count, verified core journeys, checks, and limitations.

Real authentication, payment, email, private APIs, and server persistence are not simulated as successful production actions. When they cannot truthfully run in one local file, the standalone is labeled `local-demo`; deployable service adapters remain in `source/`.

## Frontend architecture

```text
frontend/
├── index.html
├── vite.config.ts
├── package.json
├── public/
└── src/
    ├── App.vue
    ├── api.ts
    ├── types.ts
    ├── styles.css
    └── components/
```

Development server:

```bash
appforge web --no-browser
npm --prefix frontend run dev
```

Vite serves `http://127.0.0.1:5173` and proxies `/api` to FastAPI. Production assets are emitted to `appforge/resources/web/`. The retained v7 bundle is supplemented by `v11-delivery-overlay.js` so source checkouts immediately expose the v11 delivery controls even when frontend packages cannot be rebuilt locally; a normal frontend build uses the native v11 Vue components.

## User journey

1. `GET /api/health` reports LLM readiness plus web-delivery capabilities.
2. The user connects an external provider and selects a model.
3. `POST /api/jobs` receives the request. Any legacy `pipeline` field is normalized at the server boundary.
4. The UI displays the requested shape, browser adaptation, and effective web pipeline.
5. The pipeline runs planning, implementation, verification, security, and the required `web_delivery` stage.
6. The system rebuilds and validates the standalone, packages the final ZIP, then revalidates it.
7. On success, the UI presents **바로 실행 HTML 받기** first, then **전체 웹앱 ZIP 받기**, then preview.
8. Revision jobs copy the maintainable workspace but discard previous standalone files, manifests, reports, and delivery ZIPs before regeneration.

## API

### `GET /api/health`

Includes:

```json
{
  "capabilities": {
    "delivery_target": "web",
    "standalone_html": true,
    "standalone_entry": "00_START_HERE.html",
    "file_protocol_validation": true
  }
}
```

### `POST /api/jobs`

```json
{
  "prompt": "Build a Flutter-style field inspection app"
}
```

The public snapshot records `routing.requested_shape`, `routing.adaptation_profile`, `routing.effective_pipeline`, and `delivery.target`.

### `GET /api/jobs/{job_id}`

Returns pipeline stages, routing, delivery contract, standalone state, ZIP state, preview, events, usage, and a compact public error.

### `GET /api/jobs/{job_id}/standalone`

Returns only the verified `00_START_HERE.html`. It is unavailable before completion or after validation failure.

### `GET /api/jobs/{job_id}/download`

Returns only the revalidated `*-webapp.zip` stored under the project’s `.appforge/reports/` directory.

## Static and browser validation

The static audit checks document structure, visible content, unresolved local assets, required external URLs, `localhost`/WebSocket assumptions, dynamic imports and chunks, absolute file paths, local-file fetches, and secret patterns. The browser smoke checks first-screen visibility, console errors, uncaught exceptions, unhandled rejections, and external requests.

The validator first attempts a real `file://` navigation. A managed runtime that blocks all file URLs is recorded explicitly and may use the exact same fully inlined document in a browser `setContent` fallback only after the specific administrative policy error is observed. Static isolation checks still have to pass first.

## Static serving

- `/` serves `appforge/resources/web/index.html`.
- `/assets/*` serves Vite hashed assets.
- `/v11-delivery-overlay.js` serves the retained-bundle compatibility overlay.
- `/favicon.svg` and `/manifest.webmanifest` serve frontend metadata.
- unknown non-API paths fall back to the SPA shell;
- unknown `/api/*` and missing assets return 404.

## State and safety

| State | Location |
|---|---|
| generated workspaces | `projects/` |
| durable web jobs | `.appforge-web/jobs/` |
| project contract/checkpoints | `projects/<project>/.appforge/` |
| standalone | `.appforge/deliverables/00_START_HERE.html` |
| validation reports and screenshot | `.appforge/reports/` |
| delivery manifest | `.appforge/artifacts/web_delivery_manifest.json` |
| final ZIP | `.appforge/reports/*-webapp.zip` |

The server and bridge bind to loopback by default. API requests require a per-process session token. Provider secrets are not returned to the browser. Destructive and general network tools are disabled by default.

## Configuration

| Variable | Default | Purpose |
|---|---:|---|
| `APPFORGE_PROJECTS_DIR` | `projects` | generated workspaces |
| `APPFORGE_DATA_DIR` | `.appforge-web` | durable web-job state |
| `APPFORGE_DRIVER` | `llm-bridge-agent` | bridge-backed driver; CLI coding-agent drivers are rejected |
| `APPFORGE_WEB_HOST` | `127.0.0.1` | FastAPI bind host |
| `APPFORGE_WEB_PORT` | `8787` | FastAPI port |
| `APPFORGE_LLM_BRIDGE_URL` | `http://127.0.0.1:8788` | FastAPI-to-bridge URL |
| `APPFORGE_LLM_BRIDGE_AUTOSTART` | `true` | start or reuse loopback bridge |
| `APPFORGE_ALLOW_NETWORK` | `false` | allow dependency/network tools |
| `APPFORGE_ALLOW_DESTRUCTIVE` | `false` | allow destructive tools |
| `APPFORGE_STAGE_TIMEOUT` | `3600` | per-stage timeout in seconds |
| `APPFORGE_MAX_STAGE_ATTEMPTS` | configured default | automatic stage attempts |
| `APPFORGE_PROMPT_MAX_CHARS` | `20000` | prompt length limit |
