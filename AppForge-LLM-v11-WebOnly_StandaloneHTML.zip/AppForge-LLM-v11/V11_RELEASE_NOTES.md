# AppForge-LLM v11 release notes

## Browser-only product invariant

- Public greenfield routing is limited to `web-app-lite` and `web-app`.
- Existing-project work uses `feature` or `bugfix` and inherits the same web delivery contract.
- Legacy names such as `mobile-app`, `desktop-app`, `cli-tool`, `api-service`, and `fullstack-saas` remain loadable for checkpoint compatibility but are normalized at public API and CLI boundaries.
- Original intent is retained as `requested_shape` and `adaptation_profile` rather than as a non-web delivery target.

## Standalone HTML delivery

- Added `WebDeliveryContract` and project metadata with `delivery.target = "web"`.
- Added deterministic `build_standalone_html`, `validate_web_delivery`, and `package_web_delivery` tools.
- Local CSS, JavaScript, images, fonts, workers, and CSS URLs are inlined into `00_START_HERE.html`.
- Static validation rejects unresolved local assets, mandatory external runtime URLs, localhost assumptions, dynamic chunks, secrets, and unsafe absolute paths.
- Browser smoke testing checks first-screen visibility, console failures, unhandled errors, and required network isolation.
- Managed environments that block all `file://` navigation are recorded explicitly and use a strict same-document browser fallback only after the exact policy error is observed.

## Delivery package and UX

- Final ZIP root contains `00_START_HERE.html`, `README_FIRST.md`, and `DELIVERY.json`.
- Maintainable source is mapped under `source/`; an optional static build is mapped under `web-build/`.
- Archive validation rejects traversal, symlinks, duplicate/case-colliding names, missing root entries, and manifest hash mismatches.
- Added direct `GET /api/jobs/{job_id}/standalone` download.
- The completion UI prioritizes **바로 실행 HTML 받기**, followed by **전체 웹앱 ZIP 받기** and preview.
- `local-demo` limitations are surfaced next to the download actions.

## Reliability

- Repair prompts receive the same non-negotiable web delivery contract as first attempts.
- Revision workspaces discard stale standalone files and delivery metadata before rebuilding.
- Release readiness now requires standalone creation, validation, browser smoke, root-entry contract, and delivery manifest evidence.
- Tests now exercise web-only routing, project migration, prompt injection, inlining, browser validation, final ZIP structure, direct standalone download, retry, guided approval, and archive freshness.
