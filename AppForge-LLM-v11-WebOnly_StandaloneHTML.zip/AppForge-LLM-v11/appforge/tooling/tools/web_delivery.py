from __future__ import annotations

import base64
import hashlib
import html
import json
import mimetypes
import os
import re
import shutil
import subprocess
import tempfile
import urllib.parse
import zipfile
from html.parser import HTMLParser
from pathlib import Path, PurePosixPath
from typing import Any, Iterable

from appforge.constants import (
    CONTROL_DIR_NAME,
    DELIVERY_MANIFEST_NAME,
    DELIVERY_README_NAME,
    IGNORED_DIRS,
    SOURCE_ARCHIVE_DIR,
    STANDALONE_ENTRY_NAME,
    STANDALONE_HARD_LIMIT_BYTES,
    STANDALONE_WARN_BYTES,
    WEB_BUILD_ARCHIVE_DIR,
)
from appforge.models import ToolResult
from appforge.util import atomic_write_json, atomic_write_text, iter_files, read_json, safe_resolve, slugify, utc_now

from ..base import Tool

_DELIVERABLE_DIR = Path(CONTROL_DIR_NAME) / "deliverables"
_MANIFEST_PATH = Path(CONTROL_DIR_NAME) / "artifacts" / "web_delivery_manifest.json"
_VALIDATION_REPORT_PATH = Path(CONTROL_DIR_NAME) / "reports" / "web_delivery_validation.json"
_SCREENSHOT_PATH = Path(CONTROL_DIR_NAME) / "reports" / "standalone-smoke.png"

_RUNTIME_MONITOR = r"""
<script id="appforge-runtime-monitor">
(function () {
  var errors = [];
  window.__APPFORGE_RUNTIME_ERRORS__ = errors;
  function update() {
    try {
      document.documentElement.setAttribute(
        "data-appforge-runtime-errors",
        encodeURIComponent(JSON.stringify(errors))
      );
    } catch (_) {}
  }
  window.addEventListener("error", function (event) {
    errors.push(String(event.message || event.error || "window error"));
    update();
  });
  window.addEventListener("unhandledrejection", function (event) {
    errors.push(String(event.reason || "unhandled rejection"));
    update();
  });
  document.addEventListener("DOMContentLoaded", function () {
    document.documentElement.setAttribute("data-appforge-dom-ready", "true");
    update();
  });
  update();
})();
</script>
""".strip()

_SECRET_PATTERNS: tuple[tuple[str, re.Pattern[str]], ...] = (
    ("private-key", re.compile(r"-----BEGIN (?:RSA |EC |OPENSSH )?PRIVATE KEY-----")),
    ("aws-access-key", re.compile(r"\bAKIA[0-9A-Z]{16}\b")),
    ("github-token", re.compile(r"\bgh[pousr]_[A-Za-z0-9_]{30,}\b")),
    (
        "assigned-secret",
        re.compile(
            r"(?i)(?:api[_-]?key|secret|access[_-]?token|password)\s*[:=]\s*[\"']([^\"'\s]{12,})[\"']"
        ),
    ),
)

_CSS_URL_RE = re.compile(r"url\(\s*([\"']?)(.*?)\1\s*\)", re.IGNORECASE)
_CSS_IMPORT_RE = re.compile(
    r"@import\s+(?:url\(\s*)?[\"']([^\"']+)[\"']\s*\)?\s*;",
    re.IGNORECASE,
)
_JS_DYNAMIC_IMPORT_RE = re.compile(r"(?<![\w$])import\s*\(")
_JS_STATIC_IMPORT_RE = re.compile(r"(?m)^\s*(?:import|export)\s+(?!\()")


def _sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _is_external_url(value: str) -> bool:
    lowered = value.strip().casefold()
    return lowered.startswith(("http://", "https://", "//", "ws://", "wss://"))


def _is_embedded_or_nonruntime(value: str) -> bool:
    lowered = value.strip().casefold()
    return not lowered or lowered.startswith(
        ("data:", "blob:", "about:", "#", "mailto:", "tel:", "javascript:")
    )


def _clean_reference(value: str) -> str:
    return html.unescape(value).strip().strip("\"'")


def _resolve_local_reference(base_dir: Path, source_root: Path, reference: str) -> Path | None:
    reference = _clean_reference(reference)
    if _is_external_url(reference) or _is_embedded_or_nonruntime(reference):
        return None
    parsed = urllib.parse.urlsplit(reference)
    if parsed.scheme and parsed.scheme.casefold() != "file":
        return None
    raw_path = urllib.parse.unquote(parsed.path)
    if not raw_path:
        return None
    candidate = Path(raw_path)
    if candidate.is_absolute():
        candidate = source_root / raw_path.lstrip("/\\")
    else:
        candidate = base_dir / candidate
    try:
        resolved = candidate.resolve(strict=False)
        root_resolved = source_root.resolve(strict=False)
        if resolved != root_resolved and root_resolved not in resolved.parents:
            return None
        return resolved
    except OSError:
        return None


def _data_uri(path: Path) -> str:
    content = path.read_bytes()
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    return f"data:{mime};base64,{base64.b64encode(content).decode('ascii')}"


def _rewrite_css(css: str, *, css_dir: Path, source_root: Path, seen: set[Path] | None = None) -> str:
    seen = seen or set()

    def replace_import(match: re.Match[str]) -> str:
        ref = match.group(1)
        path = _resolve_local_reference(css_dir, source_root, ref)
        if path is None or not path.is_file() or path in seen:
            return match.group(0)
        seen.add(path)
        try:
            nested = path.read_text(encoding="utf-8", errors="replace")
        except OSError:
            return match.group(0)
        return f"/* inlined @import: {ref} */\n" + _rewrite_css(
            nested, css_dir=path.parent, source_root=source_root, seen=seen
        )

    css = _CSS_IMPORT_RE.sub(replace_import, css)

    def replace_url(match: re.Match[str]) -> str:
        ref = match.group(2).strip()
        if _is_external_url(ref) or _is_embedded_or_nonruntime(ref):
            return match.group(0)
        path = _resolve_local_reference(css_dir, source_root, ref)
        if path is None or not path.is_file():
            return match.group(0)
        try:
            return f'url("{_data_uri(path)}")'
        except OSError:
            return match.group(0)

    return _CSS_URL_RE.sub(replace_url, css)


def _worker_blob_expression(source: str) -> str:
    return (
        "URL.createObjectURL(new Blob(["
        + json.dumps(source, ensure_ascii=False)
        + "], {type: 'text/javascript'}))"
    )


def _rewrite_inline_workers(js: str, *, js_dir: Path, source_root: Path) -> str:
    # Convert `new URL('./worker.js', import.meta.url)` into a Blob URL. This is
    # deliberately narrow: anything more complex remains visible to validation.
    pattern = re.compile(
        r"new\s+URL\(\s*([\"'])([^\"']+\.(?:m?js|ts))\1\s*,\s*import\.meta\.url\s*\)"
    )

    def replace(match: re.Match[str]) -> str:
        ref = match.group(2)
        path = _resolve_local_reference(js_dir, source_root, ref)
        if path is None or not path.is_file():
            return match.group(0)
        source = path.read_text(encoding="utf-8", errors="replace")
        return _worker_blob_expression(source)

    return pattern.sub(replace, js)


def _format_attrs(attrs: Iterable[tuple[str, str | None]]) -> str:
    chunks: list[str] = []
    for key, value in attrs:
        if value is None:
            chunks.append(key)
        else:
            chunks.append(f'{key}="{html.escape(value, quote=True)}"')
    return (" " + " ".join(chunks)) if chunks else ""


class _InlineHTMLParser(HTMLParser):
    _ASSET_ATTRS = {
        "img": ("src",),
        "source": ("src",),
        "video": ("src", "poster"),
        "audio": ("src",),
        "track": ("src",),
        "input": ("src",),
        "object": ("data",),
        "embed": ("src",),
    }

    def __init__(self, *, html_path: Path, source_root: Path) -> None:
        super().__init__(convert_charrefs=False)
        self.html_path = html_path
        self.source_root = source_root
        self.output: list[str] = []
        self._skip_script_content = False
        self._skip_script_end = False
        self._in_style = False

    def handle_decl(self, decl: str) -> None:
        self.output.append(f"<!{decl}>")

    def handle_pi(self, data: str) -> None:
        self.output.append(f"<?{data}>")

    def handle_comment(self, data: str) -> None:
        self.output.append(f"<!--{data}-->")

    def handle_entityref(self, name: str) -> None:
        self.output.append(f"&{name};")

    def handle_charref(self, name: str) -> None:
        self.output.append(f"&#{name};")

    def _rewrite_srcset(self, value: str, base_dir: Path) -> str:
        items: list[str] = []
        for chunk in value.split(","):
            part = chunk.strip()
            if not part:
                continue
            bits = part.split()
            ref = bits[0]
            path = _resolve_local_reference(base_dir, self.source_root, ref)
            if path is not None and path.is_file():
                try:
                    bits[0] = _data_uri(path)
                except OSError:
                    pass
            items.append(" ".join(bits))
        return ", ".join(items)

    def _rewrite_attrs(self, tag: str, attrs: list[tuple[str, str | None]]) -> list[tuple[str, str | None]]:
        rewritten: list[tuple[str, str | None]] = []
        base_dir = self.html_path.parent
        for key, value in attrs:
            key_lower = key.casefold()
            if value is None:
                rewritten.append((key, value))
                continue
            new_value = value
            if key_lower == "style":
                new_value = _rewrite_css(value, css_dir=base_dir, source_root=self.source_root)
            elif key_lower == "srcset":
                new_value = self._rewrite_srcset(value, base_dir)
            elif key_lower in self._ASSET_ATTRS.get(tag.casefold(), ()):
                path = _resolve_local_reference(base_dir, self.source_root, value)
                if path is not None and path.is_file():
                    try:
                        new_value = _data_uri(path)
                    except OSError:
                        pass
            rewritten.append((key, new_value))
        return rewritten

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag_lower = tag.casefold()
        attr_map = {key.casefold(): value for key, value in attrs}
        if tag_lower == "link":
            rel = str(attr_map.get("rel") or "").casefold().split()
            href = str(attr_map.get("href") or "")
            path = _resolve_local_reference(self.html_path.parent, self.source_root, href)
            if "stylesheet" in rel and path is not None and path.is_file():
                css = path.read_text(encoding="utf-8", errors="replace")
                css = _rewrite_css(css, css_dir=path.parent, source_root=self.source_root)
                self.output.append(
                    f'<style data-appforge-inline-source="{html.escape(href, quote=True)}">{css}</style>'
                )
                return
            if any(item in rel for item in ("icon", "apple-touch-icon", "mask-icon")) and path is not None and path.is_file():
                attrs = [(key, _data_uri(path) if key.casefold() == "href" else value) for key, value in attrs]
        if tag_lower == "script" and attr_map.get("src"):
            src = str(attr_map.get("src") or "")
            path = _resolve_local_reference(self.html_path.parent, self.source_root, src)
            if path is not None and path.is_file():
                js = path.read_text(encoding="utf-8", errors="replace")
                js = _rewrite_inline_workers(js, js_dir=path.parent, source_root=self.source_root)
                kept = [
                    (key, value)
                    for key, value in attrs
                    if key.casefold() not in {"src", "integrity", "crossorigin"}
                ]
                if not _JS_STATIC_IMPORT_RE.search(js) and not _JS_DYNAMIC_IMPORT_RE.search(js):
                    kept = [(key, value) for key, value in kept if key.casefold() != "type"]
                kept.append(("data-appforge-inline-source", src))
                self.output.append(f"<script{_format_attrs(kept)}>{js}</script>")
                self._skip_script_content = True
                self._skip_script_end = True
                return
        attrs = self._rewrite_attrs(tag_lower, attrs)
        self.output.append(f"<{tag}{_format_attrs(attrs)}>")
        if tag_lower == "style":
            self._in_style = True

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        attrs = self._rewrite_attrs(tag.casefold(), attrs)
        self.output.append(f"<{tag}{_format_attrs(attrs)} />")

    def handle_endtag(self, tag: str) -> None:
        tag_lower = tag.casefold()
        if tag_lower == "script" and self._skip_script_end:
            self._skip_script_end = False
            self._skip_script_content = False
            return
        if tag_lower == "style":
            self._in_style = False
        self.output.append(f"</{tag}>")

    def handle_data(self, data: str) -> None:
        if self._skip_script_content:
            return
        if self._in_style:
            data = _rewrite_css(data, css_dir=self.html_path.parent, source_root=self.source_root)
        self.output.append(data)

    def handle_unknown_decl(self, data: str) -> None:
        self.output.append(f"<![{data}]>")

    def rendered(self) -> str:
        return "".join(self.output)


def _inject_runtime_monitor(document: str) -> str:
    if "appforge-runtime-monitor" in document:
        return document
    match = re.search(r"<head(?:\s[^>]*)?>", document, flags=re.IGNORECASE)
    if match:
        return document[: match.end()] + "\n" + _RUNTIME_MONITOR + "\n" + document[match.end() :]
    match = re.search(r"<html(?:\s[^>]*)?>", document, flags=re.IGNORECASE)
    if match:
        return document[: match.end()] + "\n<head>" + _RUNTIME_MONITOR + "</head>\n" + document[match.end() :]
    return "<!doctype html><html><head>" + _RUNTIME_MONITOR + "</head><body>" + document + "</body></html>"


def _standalone_candidates(workspace: Path) -> list[Path]:
    preferred = [
        workspace / STANDALONE_ENTRY_NAME,
        workspace / "standalone" / "index.html",
        workspace / "dist-standalone" / "index.html",
        workspace / "dist" / "index.html",
        workspace / "build" / "index.html",
        workspace / "out" / "index.html",
        workspace / "web-build" / "index.html",
        workspace / "frontend" / "dist" / "index.html",
        workspace / "index.html",
    ]
    found: list[Path] = []
    seen: set[Path] = set()
    for path in preferred:
        resolved = path.resolve(strict=False)
        if path.is_file() and resolved not in seen and CONTROL_DIR_NAME not in path.parts:
            found.append(path)
            seen.add(resolved)
    return found


def _run_project_build(workspace: Path, timeout: int) -> tuple[bool, dict[str, Any]]:
    package_path = workspace / "package.json"
    if not package_path.is_file() or shutil.which("npm") is None:
        return True, {"attempted": False, "reason": "No npm project/build runner detected."}
    try:
        package = json.loads(package_path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError):
        return False, {"attempted": False, "reason": "package.json is invalid."}
    scripts = package.get("scripts") if isinstance(package.get("scripts"), dict) else {}
    script = "build:standalone" if scripts.get("build:standalone") else "build" if scripts.get("build") else None
    if not script:
        return True, {"attempted": False, "reason": "No build or build:standalone script."}
    if not (workspace / "node_modules").exists():
        return True, {
            "attempted": False,
            "reason": "Node dependencies are not installed; using an existing HTML candidate if available.",
            "script": script,
        }
    command = ["npm", "run", script]
    completed = subprocess.run(
        command,
        cwd=workspace,
        text=True,
        capture_output=True,
        timeout=max(1, timeout),
        check=False,
        env={**os.environ, "CI": "1"},
    )
    return completed.returncode == 0, {
        "attempted": True,
        "script": script,
        "command": command,
        "returncode": completed.returncode,
        "stdout": completed.stdout[-20_000:],
        "stderr": completed.stderr[-20_000:],
    }


class _AuditHTMLParser(HTMLParser):
    _RUNTIME_ATTRS = {
        "script": ("src",),
        "img": ("src", "srcset"),
        "source": ("src", "srcset"),
        "video": ("src", "poster"),
        "audio": ("src",),
        "track": ("src",),
        "iframe": ("src",),
        "object": ("data",),
        "embed": ("src",),
        "input": ("src",),
        "form": ("action",),
    }

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.doctype = False
        self.tags: set[str] = set()
        self.runtime_refs: list[dict[str, str]] = []
        self.styles: list[str] = []
        self.scripts: list[dict[str, str]] = []
        self.text_chars = 0
        self.visual_elements = 0
        self._current_tag: str | None = None
        self._buffer: list[str] = []

    def handle_decl(self, decl: str) -> None:
        if decl.strip().casefold() == "doctype html":
            self.doctype = True

    def handle_starttag(self, tag: str, attrs: list[tuple[str, str | None]]) -> None:
        tag_lower = tag.casefold()
        self.tags.add(tag_lower)
        attr_map = {key.casefold(): value or "" for key, value in attrs}
        if tag_lower in {"canvas", "svg", "img", "video", "main"} or attr_map.get("role") == "main":
            self.visual_elements += 1
        for attr in self._RUNTIME_ATTRS.get(tag_lower, ()):
            value = attr_map.get(attr)
            if value:
                refs = [value]
                if attr == "srcset":
                    refs = [part.strip().split()[0] for part in value.split(",") if part.strip()]
                for ref in refs:
                    self.runtime_refs.append({"tag": tag_lower, "attribute": attr, "value": ref})
        if tag_lower == "link":
            rel = set(attr_map.get("rel", "").casefold().split())
            if rel & {"stylesheet", "icon", "apple-touch-icon", "mask-icon", "preload", "modulepreload", "manifest"}:
                if attr_map.get("href"):
                    self.runtime_refs.append({"tag": "link", "attribute": "href", "value": attr_map["href"]})
        if attr_map.get("style"):
            self.styles.append(attr_map["style"])
        if tag_lower == "base" and attr_map.get("href"):
            self.runtime_refs.append({"tag": "base", "attribute": "href", "value": attr_map["href"]})
        if tag_lower in {"style", "script"}:
            self._current_tag = tag_lower
            self._buffer = []
            if tag_lower == "script" and attr_map.get("src"):
                self.scripts.append({"type": attr_map.get("type", ""), "content": "", "src": attr_map["src"]})

    def handle_endtag(self, tag: str) -> None:
        tag_lower = tag.casefold()
        if self._current_tag == tag_lower:
            content = "".join(self._buffer)
            if tag_lower == "style":
                self.styles.append(content)
            else:
                self.scripts.append({"type": "inline", "content": content, "src": ""})
            self._current_tag = None
            self._buffer = []

    def handle_data(self, data: str) -> None:
        if self._current_tag:
            self._buffer.append(data)
        elif data.strip():
            self.text_chars += len(data.strip())


def _audit_standalone(document: str, *, byte_size: int) -> dict[str, Any]:
    parser = _AuditHTMLParser()
    parser.feed(document)
    errors: list[dict[str, Any]] = []
    warnings: list[dict[str, Any]] = []

    missing_tags = [tag for tag in ("html", "head", "body") if tag not in parser.tags]
    if not parser.doctype or missing_tags:
        errors.append(
            {
                "code": "HTML_STRUCTURE_INVALID",
                "detail": f"doctype={parser.doctype}; missing={missing_tags}",
            }
        )
    if parser.text_chars == 0 and parser.visual_elements == 0:
        errors.append({"code": "EMPTY_INITIAL_DOCUMENT", "detail": "No visible text or visual app root was found."})

    for reference in parser.runtime_refs:
        value = _clean_reference(reference["value"])
        if _is_embedded_or_nonruntime(value):
            continue
        if _is_external_url(value):
            errors.append({"code": "STANDALONE_EXTERNAL_DEPENDENCY", **reference})
        else:
            errors.append({"code": "STANDALONE_LOCAL_ASSET_REFERENCE", **reference})

    script_text = "\n".join(item.get("content", "") for item in parser.scripts)
    style_text = "\n".join(parser.styles)
    if _JS_DYNAMIC_IMPORT_RE.search(script_text):
        errors.append({"code": "UNRESOLVED_DYNAMIC_CHUNK", "detail": "dynamic import() remains in standalone JavaScript"})
    if _JS_STATIC_IMPORT_RE.search(script_text):
        errors.append({"code": "UNRESOLVED_MODULE_IMPORT", "detail": "static import/export remains in standalone JavaScript"})

    runtime_patterns: tuple[tuple[str, re.Pattern[str]], ...] = (
        ("fetch", re.compile(r"\bfetch\s*\(\s*([\"'])(.*?)\1", re.IGNORECASE)),
        ("websocket", re.compile(r"\b(?:WebSocket|EventSource)\s*\(\s*([\"'])(.*?)\1", re.IGNORECASE)),
        ("xhr", re.compile(r"\.open\s*\(\s*([\"'])\w+\1\s*,\s*([\"'])(.*?)\2", re.IGNORECASE)),
        ("worker", re.compile(r"\bnew\s+(?:Shared)?Worker\s*\(\s*([\"'])(.*?)\1", re.IGNORECASE)),
    )
    for kind, pattern in runtime_patterns:
        for match in pattern.finditer(script_text):
            value = match.group(match.lastindex or 1)
            if _is_embedded_or_nonruntime(value):
                continue
            errors.append(
                {
                    "code": "RUNTIME_REFERENCE_NOT_EMBEDDED",
                    "kind": kind,
                    "value": value,
                }
            )

    for match in _CSS_URL_RE.finditer(style_text):
        value = match.group(2).strip()
        if not _is_embedded_or_nonruntime(value):
            errors.append({"code": "CSS_ASSET_NOT_EMBEDDED", "value": value})
    for match in _CSS_IMPORT_RE.finditer(style_text):
        errors.append({"code": "CSS_IMPORT_NOT_INLINED", "value": match.group(1)})

    localhost = re.search(r"(?i)(?:localhost|127\.0\.0\.1|0\.0\.0\.0|ws://|wss://)", script_text + style_text)
    if localhost:
        errors.append({"code": "LOCALHOST_DEPENDENCY", "value": localhost.group(0)})

    for name, pattern in _SECRET_PATTERNS:
        if pattern.search(document):
            errors.append({"code": "SECRET_DETECTED", "kind": name})

    if byte_size >= STANDALONE_HARD_LIMIT_BYTES:
        errors.append(
            {
                "code": "STANDALONE_TOO_LARGE",
                "bytes": byte_size,
                "limit": STANDALONE_HARD_LIMIT_BYTES,
            }
        )
    elif byte_size >= STANDALONE_WARN_BYTES:
        warnings.append(
            {
                "code": "STANDALONE_SIZE_WARNING",
                "bytes": byte_size,
                "threshold": STANDALONE_WARN_BYTES,
            }
        )

    # De-duplicate identical diagnostics while preserving order.
    deduped: list[dict[str, Any]] = []
    seen: set[str] = set()
    for error in errors:
        key = json.dumps(error, ensure_ascii=False, sort_keys=True)
        if key not in seen:
            seen.add(key)
            deduped.append(error)

    return {
        "passed": not deduped,
        "doctype": parser.doctype,
        "required_tags": sorted(parser.tags & {"html", "head", "body"}),
        "visible_text_chars": parser.text_chars,
        "visual_elements": parser.visual_elements,
        "runtime_reference_count": len(parser.runtime_refs),
        "errors": deduped,
        "warnings": warnings,
    }


def _chromium_executable() -> str | None:
    for candidate in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable", "microsoft-edge"):
        path = shutil.which(candidate)
        if path:
            return path
    for path in (Path("/usr/bin/chromium"), Path("/usr/bin/google-chrome"), Path("/opt/google/chrome/chrome")):
        if path.is_file():
            return str(path)
    return None


def _browser_smoke_playwright(path: Path, screenshot: Path, timeout_seconds: int) -> dict[str, Any]:
    from playwright.sync_api import sync_playwright  # type: ignore[import-not-found]

    executable = _chromium_executable()
    external_requests: list[str] = []
    console_errors: list[str] = []
    page_errors: list[str] = []
    policy_fallback = False
    policy_error: str | None = None
    monitor_errors: list[Any] = []
    visible = False
    status: int | None = None
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch(
            executable_path=executable,
            headless=True,
            args=["--no-sandbox", "--disable-dev-shm-usage", "--disable-background-networking"],
        )
        try:
            context = browser.new_context(viewport={"width": 1280, "height": 800})
            page = context.new_page()

            def record_external(request: Any) -> None:
                url = request.url
                scheme = urllib.parse.urlsplit(url).scheme.casefold()
                if scheme not in {"file", "data", "blob", "about"} and url not in external_requests:
                    external_requests.append(url)

            def block_external(route: Any) -> None:
                record_external(route.request)
                route.abort()

            context.on("request", record_external)
            context.route(re.compile(r"^(?:https?|wss?)://", re.IGNORECASE), block_external)
            page.on("console", lambda msg: console_errors.append(msg.text) if msg.type == "error" else None)
            page.on("pageerror", lambda exc: page_errors.append(str(exc)))

            response = None
            try:
                response = page.goto(
                    path.resolve().as_uri(),
                    wait_until="domcontentloaded",
                    timeout=max(1, timeout_seconds) * 1000,
                )
            except Exception as exc:
                message = str(exc)
                if "ERR_BLOCKED_BY_ADMINISTRATOR" not in message:
                    raise
                # Managed CI images can enforce URLBlocklist=["*"], which blocks
                # file:// before application code runs. Execute the exact inlined
                # document in the same browser with network schemes blocked. The
                # preceding static audit rejects every local asset/fetch/import,
                # so this remains a strict single-file runtime equivalence check.
                policy_fallback = True
                policy_error = message
                page.close()
                page = context.new_page()
                page.on("console", lambda msg: console_errors.append(msg.text) if msg.type == "error" else None)
                page.on("pageerror", lambda exc: page_errors.append(str(exc)))
                page.set_content(
                    path.read_text(encoding="utf-8", errors="replace"),
                    wait_until="domcontentloaded",
                    timeout=max(1, timeout_seconds) * 1000,
                )

            page.wait_for_timeout(800)
            visible = bool(
                page.evaluate(
                    """() => {
                        const body = document.body;
                        if (!body) return false;
                        const text = (body.innerText || '').trim();
                        const visual = body.querySelector('canvas,svg,img,video,main,[role="main"],#app > *,#root > *');
                        const style = getComputedStyle(body);
                        return style.display !== 'none' && style.visibility !== 'hidden' && (text.length > 0 || !!visual);
                    }"""
                )
            )
            monitor_errors = page.evaluate("() => window.__APPFORGE_RUNTIME_ERRORS__ || []")
            screenshot.parent.mkdir(parents=True, exist_ok=True)
            page.screenshot(path=str(screenshot), full_page=True)
            status = response.status if response is not None else None
        finally:
            browser.close()
    all_errors = [*console_errors, *page_errors, *[str(item) for item in monitor_errors]]
    return {
        "engine": "playwright-chromium-policy-fallback" if policy_fallback else "playwright-chromium",
        "passed": visible and not all_errors and not external_requests,
        "visible": visible,
        "status": status,
        "console_errors": all_errors,
        "external_requests": external_requests,
        "screenshot": str(screenshot),
        "file_navigation_attempted": True,
        "file_navigation_blocked_by_policy": policy_fallback,
        "policy_error": policy_error,
    }


def _browser_smoke_cli(path: Path, screenshot: Path, timeout_seconds: int) -> dict[str, Any]:
    executable = _chromium_executable()
    if not executable:
        return {
            "engine": None,
            "passed": False,
            "visible": False,
            "console_errors": ["No Chromium-family browser was found."],
            "external_requests": [],
        }
    command = [
        executable,
        "--headless=new",
        "--no-sandbox",
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--disable-background-networking",
        "--disable-component-update",
        "--disable-default-apps",
        "--disable-sync",
        "--metrics-recording-only",
        "--no-first-run",
        "--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost",
        "--virtual-time-budget=2500",
        "--dump-dom",
        path.resolve().as_uri(),
    ]
    try:
        completed = subprocess.run(
            command,
            text=True,
            capture_output=True,
            timeout=max(1, timeout_seconds),
            check=False,
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "engine": "chromium-cli",
            "passed": False,
            "visible": False,
            "console_errors": [f"Chromium smoke test timed out after {timeout_seconds}s"],
            "external_requests": [],
            "screenshot": str(screenshot),
            "timeout": True,
            "stderr_tail": (exc.stderr or "")[-4000:] if isinstance(exc.stderr, str) else "",
        }
    dom = completed.stdout
    visible = bool(re.search(r"<body[^>]*>.*(?:\S).*?</body>", dom, flags=re.IGNORECASE | re.DOTALL))
    attr = re.search(r'data-appforge-runtime-errors="([^"]*)"', dom)
    monitor_errors: list[str] = []
    if attr:
        try:
            decoded = urllib.parse.unquote(html.unescape(attr.group(1)))
            payload = json.loads(decoded)
            if isinstance(payload, list):
                monitor_errors = [str(item) for item in payload]
        except (ValueError, json.JSONDecodeError):
            monitor_errors = ["Could not decode runtime error monitor output."]
    elif "data-appforge-dom-ready=\"true\"" not in dom:
        monitor_errors.append("DOMContentLoaded monitor did not complete.")

    screenshot.parent.mkdir(parents=True, exist_ok=True)
    shot_command = [
        executable,
        "--headless=new",
        "--no-sandbox",
        "--disable-gpu",
        "--disable-dev-shm-usage",
        "--disable-background-networking",
        "--host-resolver-rules=MAP * ~NOTFOUND, EXCLUDE localhost",
        "--virtual-time-budget=2500",
        f"--screenshot={screenshot}",
        "--window-size=1280,800",
        path.resolve().as_uri(),
    ]
    subprocess.run(shot_command, capture_output=True, timeout=max(1, timeout_seconds), check=False)
    stderr_errors = []
    for line in completed.stderr.splitlines():
        lowered = line.casefold()
        if "uncaught" in lowered or "unhandled" in lowered or "javascript error" in lowered:
            stderr_errors.append(line.strip())
    all_errors = [*monitor_errors, *stderr_errors]
    return {
        "engine": "chromium-cli",
        "passed": completed.returncode == 0 and visible and not all_errors,
        "visible": visible,
        "returncode": completed.returncode,
        "console_errors": all_errors,
        "external_requests": [],
        "screenshot": str(screenshot),
        "stderr_tail": completed.stderr[-4000:],
    }


def _browser_smoke(path: Path, screenshot: Path, timeout_seconds: int) -> dict[str, Any]:
    try:
        return _browser_smoke_playwright(path, screenshot, timeout_seconds)
    except Exception as exc:
        fallback = _browser_smoke_cli(path, screenshot, timeout_seconds)
        fallback["playwright_error"] = f"{type(exc).__name__}: {exc}"
        return fallback


def _project_metadata(workspace: Path) -> dict[str, Any]:
    data = read_json(workspace / CONTROL_DIR_NAME / "project.json", {})
    return data if isinstance(data, dict) else {}


def _source_build_command(workspace: Path) -> tuple[str, str | None]:
    package = read_json(workspace / "package.json", {})
    scripts = package.get("scripts") if isinstance(package, dict) and isinstance(package.get("scripts"), dict) else {}
    build = "npm run build" if scripts.get("build") else ""
    standalone = "npm run build:standalone" if scripts.get("build:standalone") else None
    return build, standalone


def _build_output_for_source(source: Path, workspace: Path) -> str | None:
    try:
        rel = source.parent.relative_to(workspace).as_posix()
    except ValueError:
        return None
    return None if rel == "." else rel


class BuildStandaloneHtmlTool(Tool):
    name = "build_standalone_html"
    description = "Build a self-contained 00_START_HERE.html from a browser application and inline local runtime assets."
    capability = "release"
    llm_exposed = True
    llm_description = (
        "Create the required standalone browser entry. It may run a detected standalone build, then inlines local CSS, JavaScript, images, fonts, and initial assets."
    )
    input_schema = {
        "type": "object",
        "properties": {
            "input_html": {"type": "string"},
            "mode": {"type": "string", "enum": ["full", "local-demo"]},
            "skip_build": {"type": "boolean"},
            "timeout": {"type": "integer", "minimum": 1, "maximum": 3600},
        },
        "additionalProperties": False,
    }
    llm_parameters = input_schema

    def execute(self, workspace: Path, inputs: dict[str, Any]) -> ToolResult:
        timeout = int(inputs.get("timeout", 900))
        output = workspace / _DELIVERABLE_DIR / STANDALONE_ENTRY_NAME
        output.parent.mkdir(parents=True, exist_ok=True)
        if output.exists():
            output.unlink()

        build_result: dict[str, Any] = {"attempted": False, "reason": "skip_build=true"}
        if not bool(inputs.get("skip_build", False)):
            ok, build_result = _run_project_build(workspace, timeout)
            if not ok:
                return ToolResult(
                    success=False,
                    error="WEB_DELIVERY_BUILD_FAILED: standalone/full web build failed",
                    data={"code": "WEB_DELIVERY_BUILD_FAILED", "build": build_result},
                )

        source: Path | None = None
        requested = inputs.get("input_html")
        if requested:
            candidate = safe_resolve(workspace, str(requested))
            if candidate.is_file():
                source = candidate
        if source is None:
            candidates = _standalone_candidates(workspace)
            source = candidates[0] if candidates else None
        if source is None:
            return ToolResult(
                success=False,
                error="STANDALONE_HTML_MISSING: no browser HTML entry was found after build",
                data={"code": "STANDALONE_HTML_MISSING", "build": build_result},
            )

        raw = source.read_text(encoding="utf-8", errors="replace")
        parser = _InlineHTMLParser(html_path=source, source_root=source.parent)
        parser.feed(raw)
        parser.close()
        document = _inject_runtime_monitor(parser.rendered())
        atomic_write_text(output, document)
        content = output.read_bytes()
        if len(content) >= STANDALONE_HARD_LIMIT_BYTES:
            output.unlink(missing_ok=True)
            return ToolResult(
                success=False,
                error="STANDALONE_HTML_INVALID: standalone exceeds the hard size limit",
                data={
                    "code": "STANDALONE_HTML_INVALID",
                    "bytes": len(content),
                    "hard_limit_bytes": STANDALONE_HARD_LIMIT_BYTES,
                },
            )

        project = _project_metadata(workspace)
        mode = str(inputs.get("mode") or project.get("standalone_mode") or "full")
        build_command, standalone_command = _source_build_command(workspace)
        record = {
            "schema_version": "1.0",
            "target": "web",
            "generated_at": utc_now(),
            "full_app": {
                "source_root": ".",
                "build_command": build_command,
                "standalone_build_command": standalone_command,
                "build_output": _build_output_for_source(source, workspace),
            },
            "standalone": {
                "path": STANDALONE_ENTRY_NAME,
                "workspace_path": output.relative_to(workspace).as_posix(),
                "source_html": source.relative_to(workspace).as_posix(),
                "mode": mode,
                "sha256": _sha256(content),
                "bytes": len(content),
                "file_protocol_supported": False,
                "external_runtime_requests": None,
                "core_journeys": ["Application launches and renders its first meaningful screen"],
            },
            "checks": {
                "html_structure": False,
                "asset_inlining": False,
                "secret_scan": False,
                "file_protocol_smoke": False,
                "console_errors": None,
                "network_isolation": False,
            },
            "limitations": [],
            "build": build_result,
        }
        atomic_write_json(workspace / _MANIFEST_PATH, record)
        return ToolResult(
            success=True,
            data={
                "path": output.relative_to(workspace).as_posix(),
                "source_html": source.relative_to(workspace).as_posix(),
                "mode": mode,
                "sha256": record["standalone"]["sha256"],
                "bytes": len(content),
                "warning": "Standalone exceeds 25 MiB" if len(content) >= STANDALONE_WARN_BYTES else None,
                "build": build_result,
            },
            artifacts=[str(output), str(workspace / _MANIFEST_PATH)],
        )


class ValidateWebDeliveryTool(Tool):
    name = "validate_web_delivery"
    description = "Validate standalone structure, inlining, secrets, network isolation, and real file:// browser startup."
    capability = "release"
    llm_exposed = True
    llm_description = "Run static and real-browser file-protocol checks on 00_START_HERE.html and write the web delivery manifest."
    input_schema = {
        "type": "object",
        "properties": {
            "path": {"type": "string"},
            "mode": {"type": "string", "enum": ["full", "local-demo"]},
            "limitations": {"type": "array", "items": {"type": "string"}},
            "core_journeys": {"type": "array", "items": {"type": "string"}},
            "timeout": {"type": "integer", "minimum": 1, "maximum": 300},
        },
        "additionalProperties": False,
    }
    llm_parameters = input_schema

    def execute(self, workspace: Path, inputs: dict[str, Any]) -> ToolResult:
        rel = str(inputs.get("path") or (_DELIVERABLE_DIR / STANDALONE_ENTRY_NAME).as_posix())
        path = safe_resolve(workspace, rel)
        if not path.is_file():
            return ToolResult(
                success=False,
                error="STANDALONE_HTML_MISSING: required standalone entry does not exist",
                data={"code": "STANDALONE_HTML_MISSING", "path": rel},
            )
        content = path.read_bytes()
        document = content.decode("utf-8", errors="replace")
        static = _audit_standalone(document, byte_size=len(content))
        if not static["passed"]:
            report = {
                "passed": False,
                "path": rel,
                "static": static,
                "browser": {"passed": False, "skipped": True, "reason": "Static validation failed first."},
                "validated_at": utc_now(),
            }
            atomic_write_json(workspace / _VALIDATION_REPORT_PATH, report)
            first = static["errors"][0] if static["errors"] else {"code": "STANDALONE_HTML_INVALID"}
            return ToolResult(
                success=False,
                error=f"{first.get('code', 'STANDALONE_HTML_INVALID')}: standalone static validation failed",
                data={"code": first.get("code", "STANDALONE_HTML_INVALID"), **report},
                artifacts=[str(workspace / _VALIDATION_REPORT_PATH)],
            )

        screenshot = workspace / _SCREENSHOT_PATH
        browser = _browser_smoke(path, screenshot, int(inputs.get("timeout", 30)))
        passed = bool(browser.get("passed")) and not browser.get("external_requests") and not browser.get("console_errors")
        report = {
            "passed": passed,
            "path": rel,
            "static": static,
            "browser": browser,
            "validated_at": utc_now(),
        }
        atomic_write_json(workspace / _VALIDATION_REPORT_PATH, report)
        if not passed:
            return ToolResult(
                success=False,
                error="FILE_PROTOCOL_SMOKE_FAILED: standalone did not pass real-browser file:// validation",
                data={"code": "FILE_PROTOCOL_SMOKE_FAILED", **report},
                artifacts=[str(workspace / _VALIDATION_REPORT_PATH)],
            )

        project = _project_metadata(workspace)
        provisional = read_json(workspace / _MANIFEST_PATH, {})
        if not isinstance(provisional, dict):
            provisional = {}
        build_command, standalone_command = _source_build_command(workspace)
        adaptation = project.get("adaptation") if isinstance(project.get("adaptation"), dict) else {}
        mode = str(inputs.get("mode") or provisional.get("standalone", {}).get("mode") or "full")
        limitations = [str(item) for item in (inputs.get("limitations") or provisional.get("limitations") or [])]
        if mode == "local-demo" and not limitations:
            limitations = [
                "Server-dependent capabilities use a local simulation in the standalone HTML; connect the deployable adapters in source/."
            ]
        core_journeys = [
            str(item)
            for item in (
                inputs.get("core_journeys")
                or provisional.get("standalone", {}).get("core_journeys")
                or ["Application launches and renders its first meaningful screen"]
            )
        ]
        manifest = {
            "schema_version": "1.0",
            "target": "web",
            "generated_at": provisional.get("generated_at") or utc_now(),
            "validated_at": utc_now(),
            "requested_shape": adaptation.get("requested_shape", "general"),
            "adaptation_profile": adaptation.get("profile", "browser-web-app"),
            "full_app": {
                "source_root": ".",
                "build_command": build_command,
                "standalone_build_command": standalone_command,
                "build_output": provisional.get("full_app", {}).get("build_output"),
            },
            "standalone": {
                "path": STANDALONE_ENTRY_NAME,
                "workspace_path": path.relative_to(workspace).as_posix(),
                "mode": mode,
                "sha256": _sha256(content),
                "bytes": len(content),
                "file_protocol_supported": True,
                "external_runtime_requests": 0,
                "core_journeys": core_journeys,
            },
            "checks": {
                "html_structure": True,
                "asset_inlining": True,
                "secret_scan": True,
                "file_protocol_smoke": True,
                "console_errors": 0,
                "network_isolation": True,
                "browser_engine": browser.get("engine"),
                "visible_first_screen": bool(browser.get("visible")),
            },
            "limitations": limitations,
        }
        atomic_write_json(workspace / _MANIFEST_PATH, manifest)
        return ToolResult(
            success=True,
            data={
                "passed": True,
                "manifest": manifest,
                "validation_report": (workspace / _VALIDATION_REPORT_PATH).relative_to(workspace).as_posix(),
                "screenshot": screenshot.relative_to(workspace).as_posix() if screenshot.exists() else None,
            },
            artifacts=[str(workspace / _MANIFEST_PATH), str(workspace / _VALIDATION_REPORT_PATH), str(screenshot)],
        )


def _safe_source_file(workspace: Path, path: Path, output: Path | None = None) -> bool:
    rel = path.relative_to(workspace).as_posix()
    lower = path.name.casefold()
    if output is not None and path.resolve(strict=False) == output.resolve(strict=False):
        return False
    if rel.startswith(f"{CONTROL_DIR_NAME}/"):
        return False
    if rel in {STANDALONE_ENTRY_NAME, DELIVERY_README_NAME, DELIVERY_MANIFEST_NAME}:
        return False
    if lower in {
        ".env",
        ".env.local",
        ".env.production",
        ".env.development",
        ".env.test",
        "id_rsa",
        "id_ed25519",
        "credentials",
        "credentials.json",
        "service-account.json",
    }:
        return False
    if lower.startswith(".env.") and lower != ".env.example":
        return False
    if path.suffix.casefold() in {".pem", ".key", ".p12", ".pfx", ".jks", ".keystore"}:
        return False
    if lower.endswith(("-webapp.zip", "-delivery.zip", "-source.zip")):
        return False
    return not path.is_symlink()


def _zip_entry_is_symlink(info: zipfile.ZipInfo) -> bool:
    mode = (info.external_attr >> 16) & 0xFFFF
    return (mode & 0o170000) == 0o120000


def _safe_zip_name(name: str) -> bool:
    if not name or "\\" in name or name.startswith(("/", "\\")):
        return False
    pure = PurePosixPath(name)
    if pure.is_absolute() or any(part in {"", ".", ".."} for part in pure.parts):
        return False
    return True


def validate_delivery_archive(path: Path) -> dict[str, Any]:
    errors: list[str] = []
    if not path.is_file():
        return {"passed": False, "errors": [f"Archive does not exist: {path}"]}
    try:
        with zipfile.ZipFile(path, "r") as archive:
            infos = archive.infolist()
            names = [info.filename for info in infos]
            if archive.testzip() is not None:
                errors.append("Archive contains a corrupt entry.")
            exact: set[str] = set()
            folded: set[str] = set()
            for info in infos:
                name = info.filename
                if not _safe_zip_name(name):
                    errors.append(f"Unsafe archive path: {name}")
                if _zip_entry_is_symlink(info):
                    errors.append(f"Symbolic link entry is not allowed: {name}")
                if name in exact:
                    errors.append(f"Duplicate archive entry: {name}")
                exact.add(name)
                folded_name = name.casefold()
                if folded_name in folded:
                    errors.append(f"Case-insensitive archive collision: {name}")
                folded.add(folded_name)
            for required in (STANDALONE_ENTRY_NAME, DELIVERY_README_NAME, DELIVERY_MANIFEST_NAME):
                if names.count(required) != 1:
                    errors.append(f"Required root entry must occur exactly once: {required}")
            if not any(name.startswith(f"{SOURCE_ARCHIVE_DIR}/") and not name.endswith("/") for name in names):
                errors.append(f"No source files were found under {SOURCE_ARCHIVE_DIR}/")
            if STANDALONE_ENTRY_NAME in names and DELIVERY_MANIFEST_NAME in names:
                html_bytes = archive.read(STANDALONE_ENTRY_NAME)
                if len(html_bytes) < 64:
                    errors.append("Standalone HTML is empty or implausibly small.")
                try:
                    delivery = json.loads(archive.read(DELIVERY_MANIFEST_NAME).decode("utf-8"))
                except (UnicodeDecodeError, json.JSONDecodeError) as exc:
                    errors.append(f"DELIVERY.json is invalid: {exc}")
                    delivery = {}
                standalone = delivery.get("standalone") if isinstance(delivery, dict) else {}
                expected_hash = standalone.get("sha256") if isinstance(standalone, dict) else None
                actual_hash = _sha256(html_bytes)
                if expected_hash != actual_hash:
                    errors.append("DELIVERY_MANIFEST_MISMATCH: standalone SHA-256 does not match.")
                audit = _audit_standalone(html_bytes.decode("utf-8", errors="replace"), byte_size=len(html_bytes))
                if not audit["passed"]:
                    errors.append("Standalone failed archive-time static validation.")
    except (OSError, zipfile.BadZipFile) as exc:
        errors.append(f"Invalid ZIP archive: {exc}")
    return {
        "passed": not errors,
        "errors": errors,
        "archive": str(path),
        "bytes": path.stat().st_size if path.exists() else None,
    }


class PackageWebDeliveryTool(Tool):
    name = "package_web_delivery"
    description = "Create and revalidate the user-facing web delivery ZIP with root standalone HTML, guidance, manifest, source/, and optional web-build/."
    capability = "release"
    llm_exposed = True
    llm_description = "Package the already validated standalone HTML and full browser source into the final safe *-webapp.zip."
    input_schema = {
        "type": "object",
        "properties": {
            "name": {"type": "string"},
            "output": {"type": "string"},
            "include_web_build": {"type": "boolean"},
            "timeout": {"type": "integer", "minimum": 1, "maximum": 300},
        },
        "additionalProperties": False,
    }
    llm_parameters = input_schema

    def execute(self, workspace: Path, inputs: dict[str, Any]) -> ToolResult:
        standalone_path = workspace / _DELIVERABLE_DIR / STANDALONE_ENTRY_NAME
        manifest_path = workspace / _MANIFEST_PATH
        manifest = read_json(manifest_path, {})
        if not standalone_path.is_file() or not isinstance(manifest, dict):
            return ToolResult(
                success=False,
                error="STANDALONE_HTML_MISSING: build and validate the standalone entry before packaging",
                data={"code": "STANDALONE_HTML_MISSING"},
            )
        standalone = manifest.get("standalone") if isinstance(manifest.get("standalone"), dict) else {}
        checks = manifest.get("checks") if isinstance(manifest.get("checks"), dict) else {}
        if not standalone.get("file_protocol_supported") or not checks.get("file_protocol_smoke"):
            return ToolResult(
                success=False,
                error="FILE_PROTOCOL_SMOKE_FAILED: unvalidated standalone cannot be packaged",
                data={"code": "FILE_PROTOCOL_SMOKE_FAILED"},
            )
        content = standalone_path.read_bytes()
        if standalone.get("sha256") != _sha256(content):
            return ToolResult(
                success=False,
                error="DELIVERY_MANIFEST_MISMATCH: standalone changed after validation",
                data={"code": "DELIVERY_MANIFEST_MISMATCH"},
            )

        project = _project_metadata(workspace)
        project_name = slugify(str(project.get("name") or workspace.name))
        requested_name = str(inputs.get("name") or f"{project_name}-webapp.zip")
        if not requested_name.casefold().endswith(".zip"):
            requested_name += ".zip"
        requested_name = Path(requested_name).name
        if not requested_name.casefold().endswith(("-webapp.zip", "-delivery.zip")):
            requested_name = Path(requested_name).stem + "-webapp.zip"
        default_output = f"{CONTROL_DIR_NAME}/reports/{requested_name}"
        output = safe_resolve(workspace, str(inputs.get("output") or default_output))
        output.parent.mkdir(parents=True, exist_ok=True)
        output.unlink(missing_ok=True)

        adaptation = project.get("adaptation") if isinstance(project.get("adaptation"), dict) else {}
        delivery_json = {
            "schema_version": "1.0",
            "app_name": str(project.get("name") or workspace.name),
            "delivery_target": "web",
            "requested_shape": manifest.get("requested_shape") or adaptation.get("requested_shape", "general"),
            "adaptation_profile": manifest.get("adaptation_profile") or adaptation.get("profile", "browser-web-app"),
            "standalone": {
                "entry": STANDALONE_ENTRY_NAME,
                "mode": standalone.get("mode", "full"),
                "sha256": standalone.get("sha256"),
                "bytes": standalone.get("bytes"),
                "file_protocol_supported": True,
                "external_runtime_requests": 0,
                "core_journeys_verified": standalone.get("core_journeys", []),
            },
            "full_app": {
                "source_dir": SOURCE_ARCHIVE_DIR,
                "build_command": manifest.get("full_app", {}).get("build_command", ""),
                "standalone_build_command": manifest.get("full_app", {}).get("standalone_build_command"),
            },
            "checks": checks,
            "limitations": manifest.get("limitations", []),
            "generated_at": utc_now(),
        }
        readme = f"""# 바로 실행하기 / Start here

1. `{STANDALONE_ENTRY_NAME}`을 더블클릭합니다. / Double-click `{STANDALONE_ENTRY_NAME}`.
2. 기본 브라우저에서 앱이 열립니다. / The app opens in your default browser.
3. 별도 설치, 터미널, 로컬 서버가 필요하지 않습니다. / No install, terminal, or local server is required.

## 전체 개발 소스 / Full source

유지보수 가능한 전체 웹앱 소스는 `{SOURCE_ARCHIVE_DIR}/`에 있습니다.
The maintainable browser application source is in `{SOURCE_ARCHIVE_DIR}/`.

## 실행 모드 / Mode

Standalone mode: `{standalone.get('mode', 'full')}`

## 제한 사항 / Limitations

""" + (
            "\n".join(f"- {item}" for item in delivery_json["limitations"])
            if delivery_json["limitations"]
            else "- 없음 / None"
        ) + "\n"

        source_files = [
            path
            for path in iter_files(workspace, ignored_dirs=IGNORED_DIRS, max_files=100_000)
            if _safe_source_file(workspace, path, output)
        ]
        if not source_files:
            return ToolResult(
                success=False,
                error="DELIVERY_ARCHIVE_INVALID: no source files are available for source/",
                data={"code": "DELIVERY_ARCHIVE_INVALID"},
            )

        include_web_build = bool(inputs.get("include_web_build", True))
        web_build_root: Path | None = None
        build_output = manifest.get("full_app", {}).get("build_output")
        if include_web_build and isinstance(build_output, str) and build_output:
            candidate = safe_resolve(workspace, build_output)
            if candidate.is_dir() and CONTROL_DIR_NAME not in candidate.parts:
                web_build_root = candidate

        with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
            # The user-facing files are intentionally first and at archive root.
            archive.writestr(STANDALONE_ENTRY_NAME, content)
            archive.writestr(DELIVERY_README_NAME, readme.encode("utf-8"))
            archive.writestr(
                DELIVERY_MANIFEST_NAME,
                (json.dumps(delivery_json, ensure_ascii=False, indent=2) + "\n").encode("utf-8"),
            )
            for path in source_files:
                rel = path.relative_to(workspace).as_posix()
                archive.write(path, arcname=f"{SOURCE_ARCHIVE_DIR}/{rel}")
            if web_build_root is not None:
                for path in iter_files(web_build_root, ignored_dirs={"node_modules", ".git"}, max_files=50_000):
                    if path.is_symlink():
                        continue
                    rel = path.relative_to(web_build_root).as_posix()
                    archive.write(path, arcname=f"{WEB_BUILD_ARCHIVE_DIR}/{rel}")

        validation = validate_delivery_archive(output)
        if not validation["passed"]:
            output.unlink(missing_ok=True)
            return ToolResult(
                success=False,
                error="DELIVERY_ARCHIVE_INVALID: " + "; ".join(validation["errors"]),
                data={"code": "DELIVERY_ARCHIVE_INVALID", "validation": validation},
            )
        package_record = {
            "archive": output.relative_to(workspace).as_posix(),
            "filename": output.name,
            "bytes": output.stat().st_size,
            "sha256": _sha256(output.read_bytes()),
            "source_files": len(source_files),
            "standalone_sha256": standalone.get("sha256"),
            "validated": True,
        }
        atomic_write_json(output.with_suffix(output.suffix + ".manifest.json"), package_record)
        return ToolResult(
            success=True,
            data={**package_record, "validation": validation},
            artifacts=[str(output), str(output.with_suffix(output.suffix + ".manifest.json"))],
        )
