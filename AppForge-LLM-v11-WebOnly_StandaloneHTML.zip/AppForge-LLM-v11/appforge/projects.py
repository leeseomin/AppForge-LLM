from __future__ import annotations

from pathlib import Path
from typing import Any

from .constants import DEFAULT_SAFETY, PROJECT_FILE_NAME, SAFETY_KEYS, STATE_FILE_NAME
from .delivery import (
    assert_web_delivery_contract,
    classify_adaptation_profile,
    default_web_delivery_contract,
    merge_web_delivery_contract,
)
from .models import ProjectLayout
from .pipelines import (
    auto_select_pipeline,
    classify_prompt_complexity,
    load_pipeline,
    routing_for_requested_pipeline,
)
from .util import atomic_write_json, atomic_write_text, read_json, slugify, utc_now


def resolve_safety(overrides: dict[str, Any] | None = None) -> dict[str, bool]:
    """Merge caller overrides onto the default safety posture, ignoring unknown keys."""
    safety = dict(DEFAULT_SAFETY)
    for key in SAFETY_KEYS:
        if overrides and key in overrides:
            safety[key] = bool(overrides[key])
    return safety


class ProjectError(ValueError):
    pass


def initialize_project(
    prompt: str,
    *,
    projects_dir: Path,
    name: str | None = None,
    pipeline_name: str = "auto",
    mode: str | None = None,
    existing_target: Path | None = None,
    safety: dict[str, Any] | None = None,
) -> ProjectLayout:
    if not prompt.strip():
        raise ProjectError("The product request cannot be empty")
    if existing_target is not None:
        root = existing_target.expanduser().resolve()
        root.mkdir(parents=True, exist_ok=True)
        if (root / ".appforge" / PROJECT_FILE_NAME).exists():
            raise FileExistsError(f"OpenAppForge is already initialized at {root}; use appforge run to resume")
        existing_repo = any(root.iterdir())
    else:
        derived = name or slugify(prompt[:72])
        root = (projects_dir / slugify(derived)).expanduser().resolve()
        root.mkdir(parents=True, exist_ok=False)
        existing_repo = False

    layout = ProjectLayout.from_root(root)
    for directory in (
        layout.control,
        layout.artifacts,
        layout.checkpoints,
        layout.prompts,
        layout.logs,
        layout.reports,
        layout.memory,
    ):
        directory.mkdir(parents=True, exist_ok=True)

    adaptation = classify_adaptation_profile(prompt)
    if pipeline_name == "auto":
        selected, scores = auto_select_pipeline(prompt, existing_repo=existing_repo)
        routing = {
            "source": "project-keyword-router",
            "requested_pipeline": "auto",
            "effective_pipeline": selected,
            "normalized": False,
            "complexity": classify_prompt_complexity(prompt),
            **adaptation,
            "delivery_target": "web",
            "standalone_required": True,
        }
    else:
        selected, routing = routing_for_requested_pipeline(
            prompt, pipeline_name, existing_repo=existing_repo
        )
        scores = {}
    pipeline = load_pipeline(selected)
    selected_mode = mode or pipeline.default_mode
    if selected_mode not in {"autonomous", "guided"}:
        raise ProjectError("mode must be 'autonomous' or 'guided'")

    project = {
        "version": "1.0",
        "name": root.name,
        "root": str(root),
        "prompt": prompt,
        "pipeline": selected,
        "pipeline_version": pipeline.version,
        "mode": selected_mode,
        "created_at": utc_now(),
        "existing_repository": existing_repo,
        "selection_scores": scores,
        "routing": routing,
        "delivery": default_web_delivery_contract(),
        "adaptation": {
            "requested_shape": adaptation["requested_shape"],
            "profile": adaptation["adaptation_profile"],
            "label": adaptation["adaptation_label"],
            "original_pipeline_request": pipeline_name,
        },
        "safety": resolve_safety(safety),
    }
    assert_web_delivery_contract(project)
    atomic_write_json(layout.control / PROJECT_FILE_NAME, project)
    atomic_write_json(
        layout.control / STATE_FILE_NAME,
        {
            "version": "1.0",
            "status": "initialized",
            "current_stage": pipeline.stages[0].name,
            "completed_stages": [],
            "updated_at": utc_now(),
        },
    )
    atomic_write_text(
        layout.control / "request.md",
        f"# Product request\n\n{prompt.strip()}\n\n"
        f"- Requested shape: `{adaptation['requested_shape']}`\n"
        f"- Web adaptation: `{adaptation['adaptation_profile']}`\n"
        f"- Effective pipeline: `{selected}`\n"
        f"- Delivery target: `web`\n"
        f"- Standalone entry: `00_START_HERE.html`\n"
        f"- Mode: `{selected_mode}`\n",
    )
    atomic_write_text(
        layout.control / "normalized_request.md",
        "# Normalized browser-web request\n\n"
        "The original request is preserved in `request.md`. The implementation target "
        "is always a browser web application. Platform terms describe interaction style, "
        "not a native deployment target.\n\n"
        f"- Original request: {prompt.strip()}\n"
        f"- Requested shape: `{adaptation['requested_shape']}`\n"
        f"- Adaptation profile: `{adaptation['adaptation_profile']}`\n"
        f"- Effective pipeline: `{selected}`\n"
        "- Required delivery: maintainable web source plus a validated, self-contained "
        "`00_START_HERE.html` that opens under `file://`.\n",
    )
    gitignore = root / ".gitignore"
    managed_entries = [
        ".appforge/logs/",
        ".appforge/prompts/",
        ".appforge/reports/",
        ".appforge/memory/",
        ".appforge/stage-result.json",
        ".env",
        ".env.*",
        "!.env.example",
    ]
    if gitignore.exists():
        current = gitignore.read_text(encoding="utf-8", errors="replace")
        missing = [entry for entry in managed_entries if entry not in current.splitlines()]
        if missing:
            suffix = "\n" if current and not current.endswith("\n") else ""
            atomic_write_text(
                gitignore,
                current + suffix + "\n# OpenAppForge generated/runtime files\n" + "\n".join(missing) + "\n",
            )
    else:
        atomic_write_text(
            gitignore,
            "# OpenAppForge generated/runtime files\n"
            + "\n".join(managed_entries)
            + "\nnode_modules/\n.venv/\n__pycache__/\ndist/\nbuild/\ncoverage/\n",
        )
    return layout


def find_project(start: Path) -> ProjectLayout:
    current = start.expanduser().resolve()
    if current.is_file():
        current = current.parent
    for candidate in (current, *current.parents):
        if (candidate / ".appforge" / PROJECT_FILE_NAME).exists():
            return ProjectLayout.from_root(candidate)
    raise ProjectError(f"No OpenAppForge project found from {start}")


def load_project(layout: ProjectLayout) -> dict[str, Any]:
    data = read_json(layout.control / PROJECT_FILE_NAME)
    if not isinstance(data, dict):
        raise ProjectError(f"Invalid project metadata at {layout.control / PROJECT_FILE_NAME}")
    # Projects created before a safety key existed must still get a defined posture
    # rather than silently falling back to "denied" for every policy-aware tool.
    stored = data.get("safety") if isinstance(data.get("safety"), dict) else {}
    data["safety"] = resolve_safety(stored)
    changed = merge_web_delivery_contract(data)
    prompt = str(data.get("prompt") or "")
    adaptation = data.get("adaptation")
    if not isinstance(adaptation, dict):
        classified = classify_adaptation_profile(prompt)
        data["adaptation"] = {
            "requested_shape": classified["requested_shape"],
            "profile": classified["adaptation_profile"],
            "label": classified["adaptation_label"],
            "original_pipeline_request": data.get("pipeline", "unknown"),
        }
        changed = True
    assert_web_delivery_contract(data)
    if changed:
        data.setdefault("migration", {})["web_delivery_contract_added"] = True
        atomic_write_json(layout.control / PROJECT_FILE_NAME, data)
    return data


def update_project(layout: ProjectLayout, updates: dict[str, Any]) -> dict[str, Any]:
    data = load_project(layout)
    data.update(updates)
    atomic_write_json(layout.control / PROJECT_FILE_NAME, data)
    return data
