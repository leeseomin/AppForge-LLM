# Browser-first web delivery contract

This contract overrides platform words in the original request and applies to every normal and repair attempt.

- Effective delivery target: a browser web application.
- Required archive-root entry: `00_START_HERE.html`.
- The standalone entry must open by double-click under `file://` without a local server, terminal, package install, or Docker.
- Preserve the requested interaction model by adapting it to the browser: mobile means touch-first responsive UX; desktop means a desktop-style browser workspace; CLI means a terminal-style web UI; API means a browser workbench and truthful local demo adapter.
- Do not satisfy the request with native binaries, Electron/Tauri-only packaging, Flutter output, terminal-only output, or server-only output.
- Produce both maintainable full web source and the standalone companion.
- Keep core domain logic browser-reusable. Separate deployable service adapters from standalone local/demo adapters.
- Inline every CSS, script, image, font, icon, initial dataset, worker, and required WASM byte used by the standalone core journey.
- Do not require a CDN, remote font, `localhost`, local-file `fetch()`, dynamic chunk, service worker, or embedded secret at standalone runtime.
- Server-only capabilities such as real authentication, payments, email, private APIs, and multi-tenant persistence must be labeled `local-demo` or `simulation`; never pretend they executed for real.
- Every revision must delete and rebuild stale standalone and delivery metadata.
- Completion requires successful full web build, standalone creation, static validation, real `file://` browser smoke, zero required external runtime requests, final delivery archive creation, and archive revalidation.
