# Browser delivery stack guidance

Choose the smallest maintainable browser architecture that supports both normal hosting and a single-file companion.

- Lightweight tools and small games may use vanilla HTML/CSS/JavaScript or TypeScript.
- Standard apps should prefer a static-build SPA such as Vite + Vue/React/Svelte; use `base: "./"` and keep a deterministic standalone build path.
- Avoid SSR-only rendering, mandatory server components, and native-only frameworks as the default product architecture.
- Configure the standalone target as one classic-script bundle with CSS and assets inlined. Disable dynamic imports/chunks or convert workers to Blob URLs and WASM/assets to embedded bytes.
- Replace `fetch('./data.json')` with embedded initial data. Skip service-worker registration under `file://`.
- Detect browser storage support and provide an in-memory fallback plus JSON import/export where persistence matters.
- Put real network integrations behind interfaces. The standalone implementation uses a local adapter and clearly surfaces limitations.
- Use the deterministic AppForge tools `build_standalone_html` and `validate_web_delivery`; do not claim that copying an ordinary `index.html` is sufficient.
