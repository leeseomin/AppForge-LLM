# Handoff director

Assemble the final engineering handoff. Verify the README and quickstart from the perspective of a new engineer. Link or name the architecture, requirements, verification, security, operations, and release artifacts that matter.

List delivered source and build artifacts, exact setup/run/test commands, configuration variables, sample data, known issues, open items, and recommended next steps. Distinguish completed scope from optional future work.

Run release readiness and create the source archive. Ensure the archive excludes credentials, dependency directories, VCS state, caches, and local-only data. Do not claim external deployment or publication.

The handoff should allow another engineer to reproduce the result without relying on hidden conversational context.

V5 hardening: handoff must point the next maintainer to the specification, workflow, memory, and loop artifacts, plus the evidence proving those contracts were implemented and verified.

## Non-developer handoff

Lead with `00_START_HERE.html`: unzip and double-click. Explain that `source/` contains the maintainable full app and that real server integrations, when present, are connected there. Never call a `local-demo` a complete production integration.

