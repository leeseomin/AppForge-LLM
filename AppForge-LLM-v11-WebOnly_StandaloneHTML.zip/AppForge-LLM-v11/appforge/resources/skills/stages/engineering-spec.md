# Engineering Spec Stage

Collapse the small-app planning work into one implementation-ready engineering spec. Prefer concrete defaults over follow-up questions unless a safety or feasibility blocker exists.

Produce `engineering_spec` with:

- Traceable requirements with acceptance criteria.
- A small screen/surface inventory including loading, empty, error, and success states where relevant.
- State/data ownership and lifecycle decisions.
- A pragmatic implementation plan sized for a lightweight web app.
- Verification steps that can be run by the implementation and verification stages.

Keep the spec short enough to guide code immediately. Do not invent enterprise architecture for a trivial or small request.

## Browser delivery requirements

Specify both the maintainable hosted web application and the self-contained standalone companion. Treat `file://` execution, zero required external runtime requests, no embedded secrets, and truthful `local-demo` limitations as acceptance requirements, not optional release polish.

