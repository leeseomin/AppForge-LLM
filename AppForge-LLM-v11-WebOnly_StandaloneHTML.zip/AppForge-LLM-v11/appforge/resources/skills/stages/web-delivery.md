# Web delivery stage

Turn the accepted browser application into two synchronized delivery forms: maintainable source and a self-contained `00_START_HERE.html`.

## Required work

1. Confirm the normal browser build is successful or truthfully identify a blocker.
2. Run `build_standalone_html`; prefer an explicit `build:standalone` script when the project defines one.
3. Run `validate_web_delivery`. It must inspect structure and references and open the result with a real browser under `file://`.
4. Record the resulting `web_delivery_manifest` artifact. Its hash, size, mode, checks, core journeys, and limitations must match the generated file.
5. A server-dependent product must use `local-demo` mode and state exactly what is simulated.

## Rejection conditions

- Missing or stale standalone output.
- Required external HTTP/CDN/font/API request.
- Local asset, dynamic chunk, module import, worker, WASM, or JSON reference left unresolved.
- `localhost`, embedded secret, absolute path, blank first screen, uncaught error, or failed file-protocol smoke.
- Treating an HTTP preview as evidence for `file://` execution.
