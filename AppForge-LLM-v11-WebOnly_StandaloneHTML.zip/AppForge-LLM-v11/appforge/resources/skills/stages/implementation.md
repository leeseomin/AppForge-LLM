# Implementation director

Implement the accepted requirements as a coherent vertical slice. Inspect the repository before choosing files or dependencies. Follow established conventions; in greenfield work, create a simple, conventional structure with one obvious start command.

Work in small integrated increments. Implement domain behavior, interfaces, validation, error handling, persistence, UI or CLI states, configuration, and tests together rather than leaving disconnected scaffolding. Use real behavior for the core product path; mocks belong at external boundaries in tests.

Add dependencies only when they materially reduce risk or complexity. Prefer maintained, focused packages and pin them through the ecosystem lockfile. Keep secrets in environment variables and provide `.env.example` with placeholders.

Write tests for acceptance behavior and important failure paths. Ensure the application can start, the library can import, or the command can execute in the available environment. **Register a runnable test command in the project manifest** — for Node projects add `"test"` to `package.json` scripts; for Python ensure `pytest` or `unittest` discovery works; for Go use `go test ./...`. The verification stage requires a detected test command and will fail if none exists. Update README with setup and run instructions. Remove placeholders, debug output, dead code, and temporary files.

Before completion, inspect the diff for unrelated changes and run the narrowest relevant checks. The implementation report must name changed files, covered requirements, commands run, decisions, and any honest gap.

V5 hardening: implement the specification, workflow, memory, and loop contracts together. Add durable state, retry budgets, idempotency guards, cancellation/escape paths, and tests for lifecycle boundaries rather than relying on hidden globals or infinite retries.

## Mandatory browser deliverables

Implement a normal static web build and a standalone build. Prefer `build` and `build:standalone` scripts. The standalone result must not depend on local `fetch()`, dynamic imports, service workers, CDNs, remote fonts, `localhost`, or embedded credentials. Use local/demo adapters for server-only behavior and ensure every revision regenerates the standalone output.

