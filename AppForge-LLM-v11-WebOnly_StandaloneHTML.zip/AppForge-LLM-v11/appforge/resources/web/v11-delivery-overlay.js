(() => {
  'use strict';

  const TOKEN_KEY = 'appforge.sessionToken';
  const jobCache = new Map();
  let scheduled = false;

  function sessionToken() {
    try {
      return window.sessionStorage.getItem(TOKEN_KEY);
    } catch {
      return null;
    }
  }

  function baseUrl() {
    const origin = window.location.origin;
    return origin && origin !== 'null' ? origin : document.baseURI;
  }

  function withToken(path) {
    try {
      const url = new URL(path, baseUrl());
      const token = sessionToken();
      if (token) url.searchParams.set('token', token);
      return url.toString();
    } catch {
      return path;
    }
  }

  function formatBytes(value) {
    if (!Number.isFinite(value) || value < 0) return '';
    if (value < 1024) return `${Math.round(value).toLocaleString('ko-KR')} B`;
    const units = ['KB', 'MB', 'GB'];
    let amount = value / 1024;
    let index = 0;
    while (amount >= 1024 && index < units.length - 1) {
      amount /= 1024;
      index += 1;
    }
    return `${amount.toFixed(amount >= 10 ? 1 : 2)} ${units[index]}`;
  }

  function setButtonLabel(anchor, label) {
    const spans = anchor.querySelectorAll('span');
    const target = spans.length ? spans[spans.length - 1] : anchor;
    if (target.textContent !== label) target.textContent = label;
  }

  function setHref(anchor, value) {
    const resolved = withToken(value);
    if (anchor.href !== resolved) anchor.href = resolved;
  }

  function setAttributeIfChanged(node, name, value) {
    if (node.getAttribute(name) !== value) node.setAttribute(name, value);
  }

  function upgradeBranding() {
    document.title = document.title.replace(/AppForge-LLM v7/g, 'AppForge-LLM v11');
    document.querySelectorAll('[aria-label*="AppForge-LLM v7"]').forEach((node) => {
      node.setAttribute('aria-label', (node.getAttribute('aria-label') || '').replace(/AppForge-LLM v7/g, 'AppForge-LLM v11'));
    });
  }

  function ensureComposerContract() {
    const textarea = document.querySelector('#promptInput');
    const form = textarea?.closest('form');
    if (!textarea || !form || form.querySelector('.v11-delivery-contract-note')) return;
    const note = document.createElement('div');
    note.className = 'v11-delivery-contract-note';
    note.setAttribute('role', 'note');
    note.innerHTML = '<span aria-hidden="true">◎</span><p><strong>모든 요청은 브라우저 웹앱으로 구현됩니다.</strong> 완료 ZIP에는 더블클릭 실행용 <code>00_START_HERE.html</code>과 전체 소스가 함께 포함됩니다.</p>';
    textarea.insertAdjacentElement('afterend', note);
  }

  function upgradePipelineLabels(panel) {
    panel.querySelectorAll('.pipeline-label').forEach((label) => {
      const text = (label.textContent || '').trim();
      if (/자동 파이프라인|mobile-app|desktop-app|cli-tool|api-service|prototype|fullstack-saas/.test(text)) {
        label.textContent = '웹앱 제작 · 브라우저 UX로 변환';
      }
    });
  }

  function jobIdFromDownload(anchor) {
    try {
      const url = new URL(anchor.href, baseUrl());
      const match = url.pathname.match(/^\/api\/jobs\/([^/]+)\/download$/);
      return match ? decodeURIComponent(match[1]) : null;
    } catch {
      return null;
    }
  }

  function renderLocalDemo(actions, standalone) {
    const panel = actions.closest('.job-panel');
    if (!panel) return;
    const existing = panel.querySelector('.v11-local-demo-notice');
    if (standalone?.mode !== 'local-demo') {
      existing?.remove();
      return;
    }
    const limitations = Array.isArray(standalone.limitations) ? standalone.limitations.map(String) : [];
    const signature = JSON.stringify(limitations);
    if (existing?.dataset.v11Signature === signature) return;
    existing?.remove();
    const note = document.createElement('div');
    note.className = 'v11-local-demo-notice';
    note.dataset.v11Signature = signature;
    note.setAttribute('role', 'note');
    const title = document.createElement('strong');
    title.textContent = '설치 없이 실행되는 로컬 데모';
    const description = document.createElement('p');
    description.textContent = '실제 서버 기능은 ZIP의 source/ 웹앱에서 연결할 수 있습니다.';
    note.append(title, description);
    if (limitations.length) {
      const list = document.createElement('ul');
      limitations.forEach((item) => {
        const li = document.createElement('li');
        li.textContent = String(item);
        list.appendChild(li);
      });
      note.appendChild(list);
    }
    actions.insertAdjacentElement('beforebegin', note);
  }

  function applyJobData(actions, data) {
    const htmlButton = actions.querySelector('[data-v11-standalone]');
    const zipButton = actions.querySelector('[data-v11-download]');
    if (!htmlButton || !zipButton) return;
    const standalone = data?.standalone;
    const download = data?.download;
    if (standalone?.available && standalone?.url) {
      setHref(htmlButton, standalone.url);
      htmlButton.classList.remove('is-disabled');
      setAttributeIfChanged(htmlButton, 'aria-disabled', 'false');
      htmlButton.removeAttribute('tabindex');
      const size = standalone.size_bytes ? ` · ${formatBytes(Number(standalone.size_bytes))}` : '';
      setButtonLabel(htmlButton, `바로 실행 HTML 받기${size}`);
    }
    if (download?.available && download?.url) {
      setHref(zipButton, download.url);
      const size = download.size_bytes ? ` · ${formatBytes(Number(download.size_bytes))}` : '';
      setButtonLabel(zipButton, `전체 웹앱 ZIP 받기${size}`);
    }
    renderLocalDemo(actions, standalone);
  }

  async function hydrateJob(actions, jobId) {
    if (jobCache.has(jobId)) {
      applyJobData(actions, jobCache.get(jobId));
      return;
    }
    try {
      const token = sessionToken();
      const response = await fetch(`/api/jobs/${encodeURIComponent(jobId)}`, {
        headers: token ? { 'X-AppForge-Token': token } : {},
      });
      if (!response.ok) return;
      const data = await response.json();
      jobCache.set(jobId, data);
      applyJobData(actions, data);
    } catch {
      // The deterministic download URLs below remain usable even if hydration fails.
    }
  }

  function ensureDeliveryActions(panel) {
    const actions = panel.querySelector('.result-actions');
    if (!actions) return;
    let zipButton = actions.querySelector('[data-v11-download]:not([data-v11-standalone])');
    if (!zipButton) {
      zipButton = Array.from(actions.querySelectorAll('a')).find((anchor) => {
        try {
          return new URL(anchor.href, baseUrl()).pathname.endsWith('/download');
        } catch {
          return false;
        }
      }) || actions.querySelector('a.download-button');
      if (!zipButton) return;
      zipButton.dataset.v11Download = 'true';
      zipButton.classList.add('is-secondary');
    }

    let htmlButton = actions.querySelector('[data-v11-standalone]');
    if (!htmlButton) {
      htmlButton = zipButton.cloneNode(true);
      delete htmlButton.dataset.v11Download;
      htmlButton.dataset.v11Standalone = 'true';
      htmlButton.classList.remove('is-secondary');
      const jobId = jobIdFromDownload(zipButton);
      if (jobId) {
        const url = new URL(zipButton.href, baseUrl());
        url.pathname = `/api/jobs/${encodeURIComponent(jobId)}/standalone`;
        setHref(htmlButton, url.toString());
        htmlButton.classList.remove('is-disabled');
        setAttributeIfChanged(htmlButton, 'aria-disabled', 'false');
        htmlButton.removeAttribute('tabindex');
        setButtonLabel(htmlButton, '바로 실행 HTML 받기');
      } else {
        htmlButton.href = '#';
        htmlButton.classList.add('is-disabled');
        htmlButton.setAttribute('aria-disabled', 'true');
        htmlButton.setAttribute('tabindex', '-1');
        setButtonLabel(htmlButton, '완료 후 바로 실행 HTML 받기');
      }
      actions.insertBefore(htmlButton, zipButton);
    }

    const jobId = jobIdFromDownload(zipButton);
    if (jobId) {
      setButtonLabel(zipButton, '전체 웹앱 ZIP 받기');
      hydrateJob(actions, jobId);
    } else {
      setButtonLabel(zipButton, '완료 후 전체 웹앱 ZIP 받기');
    }
  }

  function apply() {
    scheduled = false;
    upgradeBranding();
    ensureComposerContract();
    document.querySelectorAll('.job-panel').forEach((panel) => {
      upgradePipelineLabels(panel);
      ensureDeliveryActions(panel);
    });
  }

  function schedule() {
    if (scheduled) return;
    scheduled = true;
    window.requestAnimationFrame(apply);
  }

  const style = document.createElement('style');
  style.textContent = `
    .v11-delivery-contract-note{display:flex;gap:.75rem;align-items:flex-start;margin:.8rem 0 0;padding:.85rem 1rem;border:1px solid rgba(96,165,250,.35);border-radius:14px;background:rgba(30,64,175,.12);line-height:1.5}
    .v11-delivery-contract-note p{margin:0}.v11-delivery-contract-note strong{display:block;margin-bottom:.15rem}.v11-delivery-contract-note code{font-weight:700}
    .result-actions .download-button.is-secondary{background:transparent;border:1px solid rgba(255,255,255,.2)}
    .v11-local-demo-notice{margin:1rem 0;padding:1rem;border:1px solid rgba(251,191,36,.4);border-radius:14px;background:rgba(120,53,15,.14)}
    .v11-local-demo-notice p{margin:.35rem 0 0}.v11-local-demo-notice ul{margin:.5rem 0 0;padding-left:1.2rem}
  `;
  document.head.appendChild(style);

  const observer = new MutationObserver(schedule);
  observer.observe(document.documentElement, { childList: true, subtree: true });
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', schedule, { once: true });
  else schedule();
})();
