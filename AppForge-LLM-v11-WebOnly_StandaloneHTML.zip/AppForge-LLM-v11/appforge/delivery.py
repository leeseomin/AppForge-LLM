from __future__ import annotations

from dataclasses import asdict, dataclass
from typing import Any

from .constants import (
    DELIVERY_MANIFEST_NAME,
    DELIVERY_README_NAME,
    SOURCE_ARCHIVE_DIR,
    STANDALONE_ENTRY_NAME,
    WEB_DELIVERY_TARGET,
)

PUBLIC_GREENFIELD_PIPELINES = frozenset({"web-app-lite", "web-app"})
PUBLIC_REVISION_PIPELINES = frozenset({"feature", "bugfix"})
LEGACY_PIPELINES = frozenset(
    {
        "mobile-app",
        "desktop-app",
        "cli-tool",
        "api-service",
        "automation",
        "library-sdk",
        "data-app",
        "prototype",
        "fullstack-saas",
    }
)


@dataclass(frozen=True)
class WebDeliveryContract:
    target: str = WEB_DELIVERY_TARGET
    browser_first: bool = True
    standalone_required: bool = True
    standalone_entry: str = STANDALONE_ENTRY_NAME
    offline_core_required: bool = True
    allow_external_runtime_assets: bool = False
    require_file_protocol_smoke: bool = True
    source_dir_in_archive: str = SOURCE_ARCHIVE_DIR
    readme_name: str = DELIVERY_README_NAME
    manifest_name: str = DELIVERY_MANIFEST_NAME


def default_web_delivery_contract() -> dict[str, Any]:
    """Return the JSON shape persisted in every project.json."""
    contract = WebDeliveryContract()
    return {
        "target": contract.target,
        "browser_first": contract.browser_first,
        "standalone_html": {
            "required": contract.standalone_required,
            "entry": contract.standalone_entry,
            "offline_core_required": contract.offline_core_required,
            "file_protocol_required": contract.require_file_protocol_smoke,
            "external_runtime_assets_allowed": contract.allow_external_runtime_assets,
        },
        "archive": {
            "root_entry_required": True,
            "source_dir": contract.source_dir_in_archive,
            "readme": contract.readme_name,
            "manifest": contract.manifest_name,
        },
    }


def normalize_public_pipeline(
    requested: str | None,
    complexity: str,
    existing_repo: bool,
) -> str:
    """Map every public pipeline request to a browser-safe execution pipeline.

    ``feature`` and ``bugfix`` describe revision work, not a delivery target. All
    other public requests are normalized to one of the two web greenfield
    pipelines. Legacy names remain loadable only for checkpoint compatibility.
    """
    normalized = (requested or "auto").strip().casefold()
    if existing_repo:
        return "bugfix" if normalized == "bugfix" else "feature"
    if normalized in PUBLIC_GREENFIELD_PIPELINES:
        return normalized
    return "web-app-lite" if complexity in {"trivial", "small"} else "web-app"


_ADAPTATION_RULES: tuple[tuple[str, str, str, tuple[str, ...]], ...] = (
    (
        "mobile",
        "responsive-touch-web",
        "모바일형 터치 UX",
        ("android", "ios", "iphone", "ipad", "flutter", "react native", "mobile", "모바일", "스마트폰"),
    ),
    (
        "desktop",
        "desktop-workspace-web",
        "데스크톱형 작업공간 UX",
        ("electron", "tauri", "desktop", "데스크톱", "윈도우 앱", "macos app", "mac app"),
    ),
    (
        "cli",
        "terminal-style-web",
        "터미널형 브라우저 UX",
        ("command line", "command-line", "terminal tool", "cli", "커맨드라인", "터미널 도구", "명령줄"),
    ),
    (
        "api",
        "api-workbench-web",
        "API 워크벤치 UX",
        (
            "rest api",
            "graphql",
            "api server",
            "api service",
            "backend api",
            "webhook",
            "microservice",
            "마이크로서비스",
            "백엔드 서비스",
        ),
    ),
    (
        "automation",
        "workflow-builder-web",
        "워크플로 빌더 UX",
        ("automation", "workflow", "자동화", "워크플로", "bot", "봇"),
    ),
    (
        "library",
        "browser-playground-web",
        "브라우저 플레이그라운드 UX",
        ("sdk", "library", "라이브러리", "package", "패키지"),
    ),
    (
        "data",
        "browser-data-workbench",
        "데이터 워크벤치 UX",
        ("etl", "dashboard", "대시보드", "analytics", "분석", "csv", "dataset", "데이터 앱"),
    ),
    (
        "game",
        "browser-game",
        "브라우저 게임 UX",
        ("game", "게임", "fps", "rpg", "platformer", "시뮬레이터"),
    ),
)


def classify_adaptation_profile(prompt: str) -> dict[str, str]:
    text = prompt.casefold()
    for requested_shape, profile, label, needles in _ADAPTATION_RULES:
        if any(needle in text for needle in needles):
            return {
                "requested_shape": requested_shape,
                "adaptation_profile": profile,
                "adaptation_label": label,
            }
    return {
        "requested_shape": "general",
        "adaptation_profile": "browser-web-app",
        "adaptation_label": "브라우저 웹앱 UX",
    }


def assert_web_delivery_contract(project: dict[str, Any]) -> None:
    delivery = project.get("delivery")
    if not isinstance(delivery, dict):
        raise ValueError("project.delivery is missing")
    if delivery.get("target") != WEB_DELIVERY_TARGET:
        raise ValueError("project.delivery.target must be 'web'")
    if delivery.get("browser_first") is not True:
        raise ValueError("project.delivery.browser_first must be true")
    standalone = delivery.get("standalone_html")
    if not isinstance(standalone, dict):
        raise ValueError("project.delivery.standalone_html is missing")
    if standalone.get("required") is not True:
        raise ValueError("standalone HTML must be required")
    if standalone.get("entry") != STANDALONE_ENTRY_NAME:
        raise ValueError(f"standalone entry must be {STANDALONE_ENTRY_NAME}")
    if standalone.get("file_protocol_required") is not True:
        raise ValueError("file-protocol smoke validation must be required")
    if standalone.get("external_runtime_assets_allowed") is not False:
        raise ValueError("external runtime assets must be disallowed")


def merge_web_delivery_contract(project: dict[str, Any]) -> bool:
    """Migrate old project metadata in place; return whether it changed."""
    expected = default_web_delivery_contract()
    current = project.get("delivery")
    if current == expected:
        return False
    project["delivery"] = expected
    return True


def contract_asdict() -> dict[str, Any]:
    """Flat form useful for diagnostics and health endpoints."""
    return asdict(WebDeliveryContract())
