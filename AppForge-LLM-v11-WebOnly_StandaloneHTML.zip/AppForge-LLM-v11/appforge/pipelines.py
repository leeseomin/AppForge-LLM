from __future__ import annotations

import json
from functools import lru_cache
from pathlib import Path
from typing import Any

import jsonschema
import yaml

from .constants import PIPELINE_DIR, SCHEMAS_DIR, WEB_DELIVERY_TARGET
from .delivery import (
    LEGACY_PIPELINES,
    PUBLIC_GREENFIELD_PIPELINES,
    PUBLIC_REVISION_PIPELINES,
    classify_adaptation_profile,
    normalize_public_pipeline,
)
from .models import PipelineSpec


class PipelineValidationError(ValueError):
    pass


@lru_cache(maxsize=1)
def _schema() -> dict[str, Any]:
    with (SCHEMAS_DIR / "pipeline.schema.json").open("r", encoding="utf-8") as handle:
        return json.load(handle)


def list_pipeline_names(directory: Path | None = None) -> list[str]:
    """Return every bundled pipeline, including legacy checkpoint definitions."""
    base = directory or PIPELINE_DIR
    return sorted(path.stem for path in base.glob("*.yaml"))


def list_public_pipeline_names(*, existing_repo: bool | None = None) -> list[str]:
    """Return only pipeline names users may select in the browser-first product."""
    if existing_repo is True:
        names = PUBLIC_REVISION_PIPELINES
    elif existing_repo is False:
        names = PUBLIC_GREENFIELD_PIPELINES
    else:
        names = PUBLIC_GREENFIELD_PIPELINES | PUBLIC_REVISION_PIPELINES
    return sorted(names)


def load_pipeline(name: str, directory: Path | None = None) -> PipelineSpec:
    base = directory or PIPELINE_DIR
    path = base / f"{name}.yaml"
    if not path.exists():
        available = ", ".join(list_pipeline_names(base))
        raise FileNotFoundError(f"Pipeline {name!r} not found. Available: {available}")
    with path.open("r", encoding="utf-8") as handle:
        raw = yaml.safe_load(handle)
    try:
        jsonschema.validate(raw, _schema())
    except jsonschema.ValidationError as exc:
        raise PipelineValidationError(f"Invalid pipeline {name!r}: {exc.message}") from exc
    spec = PipelineSpec.from_dict(raw)
    stage_names = [stage.name for stage in spec.stages]
    if len(stage_names) != len(set(stage_names)):
        raise PipelineValidationError(f"Pipeline {name!r} contains duplicate stage names")
    return spec


def all_pipelines(directory: Path | None = None) -> list[PipelineSpec]:
    return [load_pipeline(name, directory) for name in list_pipeline_names(directory)]


_COMPLEXITY_COMPLEX_HINTS = (
    "saas",
    "multi-tenant",
    "멀티테넌트",
    "subscription",
    "구독",
    "payment",
    "결제",
    "role",
    "permission",
    "권한",
    "admin",
    "관리자",
    "realtime",
    "실시간",
    "websocket",
    "api",
    "backend",
    "백엔드",
    "database",
    "데이터베이스",
    "auth",
    "인증",
    "login",
    "로그인",
    "deploy",
    "배포",
    "production",
    "운영",
    "analytics",
    "분석",
)

_SMALL_APP_HINTS = (
    "todo",
    "to-do",
    "투두",
    "memo",
    "메모",
    "calculator",
    "계산기",
    "timer",
    "타이머",
    "simple",
    "small",
    "tiny",
    "간단",
    "작은",
    "가벼운",
    "landing",
    "랜딩",
    "one page",
    "단일 페이지",
    "prototype",
    "프로토타입",
    "poc",
)

_CLASSIFIER_SCHEMA: dict[str, Any] = {
    "type": "json_schema",
    "json_schema": {
        "name": "appforge_web_request_route",
        "schema": {
            "type": "object",
            "required": [
                "complexity",
                "requested_shape",
                "adaptation_profile",
                "confidence",
                "rationale",
            ],
            "properties": {
                "complexity": {
                    "type": "string",
                    "enum": ["trivial", "small", "standard", "complex"],
                },
                "requested_shape": {
                    "type": "string",
                    "enum": [
                        "mobile",
                        "desktop",
                        "cli",
                        "api",
                        "automation",
                        "library",
                        "data",
                        "game",
                        "general",
                    ],
                },
                "adaptation_profile": {"type": "string"},
                "confidence": {"type": "number", "minimum": 0, "maximum": 1},
                "rationale": {"type": "string"},
            },
            "additionalProperties": False,
        },
        "strict": True,
    },
}


def classify_prompt_complexity(prompt: str) -> str:
    """Cheap local complexity classifier used before/after the optional LLM router."""
    text = prompt.casefold()
    complex_hits = sum(1 for hint in _COMPLEXITY_COMPLEX_HINTS if hint in text)
    if complex_hits >= 4 or (complex_hits >= 2 and len(prompt) > 500) or len(prompt) > 1800:
        return "complex"
    if complex_hits:
        return "standard"
    if len(prompt) <= 80:
        return "trivial"
    if any(hint in text for hint in _SMALL_APP_HINTS) or len(prompt) <= 220:
        return "small"
    return "standard"


def _keyword_scores(prompt: str, *, existing_repo: bool = False) -> tuple[str, dict[str, int]]:
    complexity = classify_prompt_complexity(prompt)
    adaptation = classify_adaptation_profile(prompt)
    selected = normalize_public_pipeline(None, complexity, existing_repo)
    if existing_repo:
        text = prompt.casefold()
        if any(needle in text for needle in ("bug", "버그", "오류", "crash", "fix", "고쳐", "회귀")):
            selected = "bugfix"
        else:
            selected = "feature"
    scores = {name: 0 for name in list_pipeline_names()}
    scores[selected] = 100
    scores["_complexity_small"] = 1 if complexity in {"trivial", "small"} else 0
    scores["_web_delivery"] = 1
    scores[f"_shape_{adaptation['requested_shape']}"] = 1
    return selected, scores


def routing_for_requested_pipeline(
    prompt: str,
    requested: str | None,
    *,
    existing_repo: bool,
) -> tuple[str, dict[str, Any]]:
    """Normalize an explicit API/CLI pipeline without letting it escape web delivery."""
    complexity = classify_prompt_complexity(prompt)
    adaptation = classify_adaptation_profile(prompt)
    requested_value = (requested or "auto").strip()
    if requested_value in {"", "auto"}:
        effective, _scores = _keyword_scores(prompt, existing_repo=existing_repo)
    else:
        effective = normalize_public_pipeline(requested_value, complexity, existing_repo)
    normalized = requested_value not in {"", "auto", effective}
    reason = (
        "Public AppForge output is always a browser web application."
        if normalized
        else "The request already maps to a public browser-web pipeline."
    )
    return effective, {
        "source": "explicit-normalized" if requested_value not in {"", "auto"} else "keyword-fallback",
        "requested_pipeline": requested_value or "auto",
        "pipeline": effective,
        "effective_pipeline": effective,
        "normalized": normalized,
        "reason": reason,
        "confidence": 1.0 if requested_value not in {"", "auto"} else 0.55,
        "complexity": complexity,
        "requested_shape": adaptation["requested_shape"],
        "adaptation_profile": adaptation["adaptation_profile"],
        "adaptation_label": adaptation["adaptation_label"],
        "delivery_target": WEB_DELIVERY_TARGET,
        "standalone_required": True,
        "rationale": reason,
    }


def _route_prompt_for_llm(prompt: str, *, existing_repo: bool) -> str:
    return (
        "Classify the original interaction shape and implementation complexity. "
        "Do not choose a native/desktop/CLI/server pipeline: AppForge itself always "
        "delivers a browser web application. A mobile request means a touch-first web UX; "
        "a desktop request means a desktop-style browser workspace; a CLI request means a "
        "terminal-style web UI; an API request means a browser API workbench/local demo.\n\n"
        f"existing_repo: {existing_repo}\n"
        f"request:\n{prompt}\n"
    )


def _coerce_llm_route(payload: Any, *, prompt: str, existing_repo: bool) -> dict[str, Any] | None:
    if not isinstance(payload, dict):
        return None
    complexity = str(payload.get("complexity") or classify_prompt_complexity(prompt)).strip().casefold()
    if complexity not in {"trivial", "small", "standard", "complex"}:
        complexity = classify_prompt_complexity(prompt)
    local_adaptation = classify_adaptation_profile(prompt)
    requested_shape = str(payload.get("requested_shape") or local_adaptation["requested_shape"]).strip().casefold()
    if requested_shape not in {
        "mobile",
        "desktop",
        "cli",
        "api",
        "automation",
        "library",
        "data",
        "game",
        "general",
    }:
        requested_shape = local_adaptation["requested_shape"]
    adaptation_profile = str(payload.get("adaptation_profile") or "").strip()
    if not adaptation_profile:
        adaptation_profile = local_adaptation["adaptation_profile"]
    try:
        confidence = float(payload.get("confidence", 0))
    except (TypeError, ValueError):
        confidence = 0.0
    confidence = max(0.0, min(1.0, confidence))
    rationale = str(payload.get("rationale") or "LLM classifier returned no rationale.").strip()
    # Backward-compatible provider responses may still contain a legacy pipeline.
    requested_pipeline = str(payload.get("pipeline") or "").strip() or None
    effective = normalize_public_pipeline(requested_pipeline, complexity, existing_repo)
    if existing_repo and requested_pipeline == "bugfix":
        effective = "bugfix"
    return {
        "pipeline": effective,
        "effective_pipeline": effective,
        "requested_pipeline": requested_pipeline,
        "complexity": complexity,
        "requested_shape": requested_shape,
        "adaptation_profile": adaptation_profile,
        "adaptation_label": local_adaptation["adaptation_label"],
        "confidence": confidence,
        "rationale": rationale,
        "delivery_target": WEB_DELIVERY_TARGET,
        "standalone_required": True,
    }


def _extract_json_object(text: str) -> Any:
    """Extract the first JSON object from a provider response."""
    stripped = text.strip()
    if not stripped:
        raise ValueError("empty LLM route response")
    if stripped.startswith("```"):
        lines = stripped.splitlines()
        if lines and lines[0].startswith("```"):
            lines = lines[1:]
        if lines and lines[-1].strip().startswith("```"):
            lines = lines[:-1]
        stripped = "\n".join(lines).strip()
    try:
        return json.loads(stripped)
    except json.JSONDecodeError:
        pass
    decoder = json.JSONDecoder()
    start = stripped.find("{")
    while start != -1:
        try:
            payload, _ = decoder.raw_decode(stripped[start:])
            return payload
        except json.JSONDecodeError:
            start = stripped.find("{", start + 1)
    raise ValueError("route response did not contain a JSON object")


def _try_llm_route(
    prompt: str,
    *,
    existing_repo: bool,
    llm_bridge_url: str | None,
    provider: str | None = None,
    model: str | None = None,
    max_tokens: int | None = None,
    temperature: float | None = None,
    top_p: float | None = None,
    timeout: int = 8,
) -> tuple[str, dict[str, int], dict[str, Any]] | None:
    if not llm_bridge_url:
        return None
    try:
        from . import llm_bridge

        response = llm_bridge.generate(
            llm_bridge_url,
            prompt=_route_prompt_for_llm(prompt, existing_repo=existing_repo),
            system=(
                "You are a conservative browser-product request classifier. "
                "Return only the requested JSON decision."
            ),
            provider=provider,
            model=model,
            max_tokens=600 if max_tokens is None else max_tokens,
            temperature=0 if temperature is None else temperature,
            top_p=top_p,
            response_format=_CLASSIFIER_SCHEMA,
            timeout=timeout,
        )
        payload = _extract_json_object(str(response.get("text") or "{}"))
        routing = _coerce_llm_route(payload, prompt=prompt, existing_repo=existing_repo)
        if routing is None:
            return None
        pipeline = str(routing["pipeline"])
        confidence = float(routing["confidence"])
        complexity = str(routing["complexity"])
        scores = {name: 0 for name in list_pipeline_names()}
        scores[pipeline] = int(round(confidence * 100))
        scores["_llm_confidence"] = int(round(confidence * 100))
        scores["_llm_complexity_small"] = 1 if complexity in {"trivial", "small"} else 0
        scores["_llm_route"] = 1
        routing.update(
            {
                "source": "llm-router",
                "usage": response.get("usage") or {},
            }
        )
        return pipeline, scores, routing
    except Exception:
        return None


def auto_select_pipeline(
    prompt: str,
    *,
    existing_repo: bool = False,
    llm_bridge_url: str | None = None,
    llm_provider: str | None = None,
    llm_model: str | None = None,
    max_tokens: int | None = None,
    temperature: float | None = None,
    top_p: float | None = None,
    timeout: int = 8,
) -> tuple[str, dict[str, int]]:
    llm = _try_llm_route(
        prompt,
        existing_repo=existing_repo,
        llm_bridge_url=llm_bridge_url,
        provider=llm_provider,
        model=llm_model,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        timeout=timeout,
    )
    if llm is not None:
        pipeline, scores, routing = llm
        if float(routing.get("confidence") or 0.0) >= 0.6:
            return pipeline, scores
    return _keyword_scores(prompt, existing_repo=existing_repo)


def select_pipeline(
    prompt: str,
    *,
    existing_repo: bool = False,
    bridge_url: str | None = None,
    provider: str | None = None,
    model: str | None = None,
    max_tokens: int | None = None,
    temperature: float | None = None,
    top_p: float | None = None,
    timeout: int = 8,
) -> tuple[str, dict[str, Any]]:
    """Return a web-only pipeline and user-visible adaptation metadata."""
    fallback, scores = _keyword_scores(prompt, existing_repo=existing_repo)
    complexity = classify_prompt_complexity(prompt)
    adaptation = classify_adaptation_profile(prompt)
    routing: dict[str, Any] = {
        "source": "keyword-fallback",
        "pipeline": fallback,
        "effective_pipeline": fallback,
        "requested_pipeline": "auto",
        "confidence": 0.55,
        "complexity": complexity,
        "requested_shape": adaptation["requested_shape"],
        "adaptation_profile": adaptation["adaptation_profile"],
        "adaptation_label": adaptation["adaptation_label"],
        "delivery_target": WEB_DELIVERY_TARGET,
        "standalone_required": True,
        "rationale": "키워드/복잡도 라우터가 웹 파이프라인과 브라우저 UX 적응 방식을 선택했습니다.",
        "scores": scores,
    }
    llm = _try_llm_route(
        prompt,
        existing_repo=existing_repo,
        llm_bridge_url=bridge_url,
        provider=provider,
        model=model,
        max_tokens=max_tokens,
        temperature=temperature,
        top_p=top_p,
        timeout=timeout,
    )
    if llm is None:
        return fallback, routing
    selected, llm_scores, llm_routing = llm
    confidence = float(llm_routing.get("confidence") or 0.0)
    llm_routing["scores"] = llm_scores
    llm_routing["fallback_pipeline"] = fallback
    if confidence < 0.6:
        routing.update(
            {
                "source": "llm-router-low-confidence-fallback",
                "llm_candidate": selected,
                "llm_confidence": confidence,
                "llm_rationale": llm_routing.get("rationale"),
                "usage": llm_routing.get("usage") or {},
                "low_confidence_candidates": [
                    candidate for candidate in (selected, fallback) if candidate
                ],
            }
        )
        return fallback, routing
    return selected, llm_routing


__all__ = [
    "LEGACY_PIPELINES",
    "PipelineValidationError",
    "all_pipelines",
    "auto_select_pipeline",
    "classify_prompt_complexity",
    "list_pipeline_names",
    "list_public_pipeline_names",
    "load_pipeline",
    "routing_for_requested_pipeline",
    "select_pipeline",
]
