from __future__ import annotations

import json

from appforge.artifacts import load_artifact_schema
from appforge.constants import SKILLS_DIR
from appforge.pipelines import (
    all_pipelines,
    auto_select_pipeline,
    list_pipeline_names,
    list_public_pipeline_names,
    routing_for_requested_pipeline,
    select_pipeline,
)
from appforge.tooling.registry import ToolRegistry


def test_all_builtin_pipelines_are_valid_and_resolvable() -> None:
    expected = {
        "api-service",
        "automation",
        "bugfix",
        "cli-tool",
        "data-app",
        "desktop-app",
        "feature",
        "fullstack-saas",
        "library-sdk",
        "mobile-app",
        "prototype",
        "web-app",
        "web-app-lite",
    }
    assert set(list_pipeline_names()) == expected
    assert set(list_public_pipeline_names()) == {"web-app-lite", "web-app", "feature", "bugfix"}
    tool_names = set(ToolRegistry().names())
    for pipeline in all_pipelines():
        assert pipeline.stages
        assert len({stage.name for stage in pipeline.stages}) == len(pipeline.stages)
        for stage in pipeline.stages:
            assert (SKILLS_DIR / stage.skill).is_file()
            for artifact in stage.produces:
                assert load_artifact_schema(artifact)["type"] == "object"
            assert set(stage.tools).issubset(tool_names)
            assert {gate.tool for gate in stage.gates}.issubset(tool_names)


def test_router_preserves_requested_shape_but_only_selects_public_web_pipelines() -> None:
    cases = [
        ("Build a Flutter mobile app for field inspections", False, "web-app-lite", "mobile"),
        ("멀티테넌트 구독형 SaaS를 만들어라", False, "web-app", "general"),
        ("간헐적으로 결제가 두 번 생성되는 버그를 고쳐라", True, "bugfix", "general"),
        ("Create a command line log analyzer", False, "web-app-lite", "cli"),
        ("기존 프로젝트에 관리자 감사 로그 기능 추가", True, "feature", "general"),
        ("Build an idempotent webhook API backend", False, "web-app", "api"),
        ("빠른 MVP 프로토타입을 만들어라", False, "web-app-lite", "general"),
    ]
    for prompt, existing, expected, requested_shape in cases:
        selected, scores = auto_select_pipeline(prompt, existing_repo=existing)
        assert selected == expected, scores
        effective, routing = routing_for_requested_pipeline(prompt, None, existing_repo=existing)
        assert effective == expected
        assert routing["effective_pipeline"] == expected
        assert routing["delivery_target"] == "web"
        assert routing["standalone_required"] is True
        assert routing["requested_shape"] == requested_shape


def test_explicit_legacy_pipeline_is_normalized_instead_of_exposed() -> None:
    effective, routing = routing_for_requested_pipeline(
        "Build a Flutter mobile app",
        "mobile-app",
        existing_repo=False,
    )

    assert effective == "web-app-lite"
    assert routing["requested_pipeline"] == "mobile-app"
    assert routing["effective_pipeline"] == "web-app-lite"
    assert routing["normalized"] is True
    assert routing["requested_shape"] == "mobile"


def test_low_confidence_llm_route_preserves_usage(monkeypatch) -> None:
    monkeypatch.setattr(
        "appforge.llm_bridge.generate",
        lambda *args, **kwargs: {
            "text": json.dumps(
                {
                    "pipeline": "mobile-app",
                    "complexity": "standard",
                    "requested_shape": "mobile",
                    "adaptation_profile": "responsive-touch-web",
                    "confidence": 0.4,
                    "rationale": "The local fallback is a better fit.",
                }
            ),
            "usage": {"inputTokens": 25, "outputTokens": 10, "totalTokens": 35},
        },
    )

    selected, routing = select_pipeline(
        "빠른 MVP 프로토타입을 만들어라",
        bridge_url="http://bridge.test",
    )

    assert selected == "web-app-lite"
    assert routing["source"] == "llm-router-low-confidence-fallback"
    assert routing["delivery_target"] == "web"
    assert routing["standalone_required"] is True
    assert routing["usage"] == {"inputTokens": 25, "outputTokens": 10, "totalTokens": 35}
