from __future__ import annotations

from appforge.pipelines import load_pipeline
from appforge.projects import initialize_project, load_project
from appforge.prompting import build_repair_stage_prompt, build_stage_prompt


def test_stage_and_repair_packets_contain_web_delivery_contract(tmp_path) -> None:
    layout = initialize_project(
        "Build an accessible React web app with login",
        projects_dir=tmp_path,
        name="packet",
        pipeline_name="web-app",
    )
    project = load_project(layout)
    pipeline = load_pipeline("web-app")
    stage = pipeline.stage("intake")
    packet = build_stage_prompt(
        layout,
        project=project,
        pipeline=pipeline,
        stage=stage,
        attempt=1,
    )
    assert "product_brief" in packet
    assert "stage-result.json" in packet
    assert "External actions" in packet or "external" in packet.casefold()
    assert "Build an accessible React web app with login" in packet
    assert "Non-negotiable web delivery contract" in packet
    assert "00_START_HERE.html" in packet
    assert "file://" in packet
    assert "build_standalone_html" in packet

    repair = build_repair_stage_prompt(
        layout,
        project=project,
        pipeline=pipeline,
        stage=stage,
        attempt=2,
        previous_failure={
            "repair_mode": "repair",
            "summary": "Standalone entry was missing.",
            "errors": ["STANDALONE_HTML_MISSING"],
        },
    )
    assert "Non-negotiable web delivery contract" in repair
    assert "00_START_HERE.html" in repair
    assert "Every revision must delete and rebuild stale standalone" in repair


def test_native_request_is_reframed_with_browser_stack_guidance(tmp_path) -> None:
    layout = initialize_project(
        "Build a Flutter mobile app for inspections",
        projects_dir=tmp_path,
        name="flutter-adapted",
        pipeline_name="mobile-app",
    )
    project = load_project(layout)
    pipeline = load_pipeline(project["pipeline"])
    packet = build_stage_prompt(
        layout,
        project=project,
        pipeline=pipeline,
        stage=pipeline.stage("intake"),
        attempt=1,
    )

    assert project["pipeline"] in {"web-app-lite", "web-app"}
    assert project["adaptation"]["requested_shape"] == "mobile"
    assert "mobile means touch-first responsive UX" in packet
    assert "Browser delivery stack guidance" in packet
    assert "Do not satisfy the request with native binaries" in packet
