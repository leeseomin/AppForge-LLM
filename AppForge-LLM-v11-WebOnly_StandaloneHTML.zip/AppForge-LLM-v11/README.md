# AppForge-LLM v11

**A browser-first AI app builder that turns any app-shaped request into a maintainable web project and a validated, double-click standalone HTML companion.**

[한국어 문서](README.ko.md) · [v11 release notes](V11_RELEASE_NOTES.md) · [Web guide](docs/WEB_APP.md) · [Architecture](docs/ARCHITECTURE.md) · [Safety](docs/SAFETY.md) · [Changelog](CHANGELOG.md)

AppForge v11 separates the user’s requested interaction shape from the delivery target. A mobile request becomes a touch-first responsive web app, a desktop request becomes a desktop-style browser workspace, a CLI request becomes a terminal-style web UI, and an API request becomes a browser workbench with a truthful local-demo adapter. Public greenfield jobs always use `web-app-lite` or `web-app`; revision jobs use `feature` or `bugfix` while retaining the web delivery contract.

```text
Connect an LLM → Describe any app → Adapt it to the browser → Build and verify
→ Create 00_START_HERE.html → Run file:// smoke tests → Package and revalidate
```

## Guaranteed delivery contract

A job is not completed merely because source generation or a normal build succeeded. Completion requires all of the following:

- a maintainable browser application source tree;
- a self-contained `.appforge/deliverables/00_START_HERE.html`;
- static checks for unresolved assets, external runtime dependencies, local-server assumptions, dynamic chunks, and exposed secrets;
- a browser startup smoke test with required network access blocked;
- a delivery manifest whose SHA-256 matches the standalone file;
- a re-opened and revalidated user ZIP.

The final ZIP is intentionally organized for both beginners and developers:

```text
my-app-webapp.zip
├── 00_START_HERE.html       # double-click entry
├── README_FIRST.md          # one-minute instructions
├── DELIVERY.json            # mode, hashes, checks, limitations
├── source/                  # maintainable full web source
└── web-build/               # optional static-hosting build
```

Server-dependent capabilities such as real authentication, payment, email, private APIs, or multi-tenant persistence are never faked in the standalone file. They are exposed as a clearly labeled `local-demo` or simulation, while the deployable adapters remain in `source/`.

## Product capabilities

- External LLM provider connection through the local Bun bridge.
- Autonomous or approval-checkpoint execution.
- Durable queued jobs, retries, cancellation, revision jobs, artifacts, and workspace inspection.
- Web-only routing with preserved mobile/desktop/CLI/API/game interaction profiles.
- Deterministic `build_standalone_html`, `validate_web_delivery`, and `package_web_delivery` tools.
- Direct **Download standalone HTML** action before **Download full web app ZIP**.
- Preview support that prefers the validated standalone entry after delivery generation.
- Archive traversal, symlink, duplicate-name, secret-file, and manifest-hash protections.

AppForge does not automatically deploy generated apps or mutate production data.

## Quick start

Requirements: Python 3.11+, Node.js/npm, Bun, and an external LLM account or API key.

```bash
./build.sh
```

The launcher prepares the Python environment, builds the Vue UI, starts or reuses the local LLM bridge, starts FastAPI, and opens the browser. The web UI defaults to `http://127.0.0.1:8787`; the bridge defaults to `http://127.0.0.1:8788`.

Useful commands:

```bash
./build.sh --no-open
./build.sh --check
APPFORGE_SKIP_INSTALL=1 APPFORGE_SKIP_FRONTEND_BUILD=1 ./build.sh --smoke
```

## Development and verification

```bash
python -m venv .venv
source .venv/bin/activate
python -m pip install -e '.[dev]'
npm --prefix frontend install
(cd llm_bridge && bun install)

python -m compileall -q appforge tests
python -m pytest
npm --prefix frontend run build
(cd llm_bridge && bun run typecheck && bun test)
python -m pip wheel . --no-deps --no-build-isolation -w dist
```

For frontend development:

```bash
appforge web --no-browser
npm --prefix frontend run dev
```

Open `http://127.0.0.1:5173`; Vite proxies `/api` to FastAPI.

## Local state and safety

| State | Authoritative location |
|---|---|
| Generated projects | `projects/` |
| Web jobs and logs | `.appforge-web/` |
| Project artifacts/checkpoints | `projects/<project>/.appforge/` |
| Standalone and delivery reports | `projects/<project>/.appforge/deliverables/`, `artifacts/`, `reports/` |
| Provider configuration | `~/.appforge/llm/providers.json` by default |

The server and bridge bind to loopback by default. API requests use a per-process session token. Provider secrets are not returned to the browser. Network-capable and destructive tools remain disabled by default.

## License

Apache-2.0. See [LICENSE](LICENSE) and [ATTRIBUTION.md](ATTRIBUTION.md).
